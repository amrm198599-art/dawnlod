const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const path = require('path');
const fs = require('fs-extra');
const http = require('http');
const { Server } = require('socket.io');
const { DOWNLOADS_DIR, isTempFile } = require('./utils/paths');
const { requireApiKey, socketAuth, authEnabled } = require('./middleware/auth');
const { rateLimit } = require('./utils/rateLimit');
const files = require('./routes/files');

const isProd = process.env.NODE_ENV === 'production';
const PORT = process.env.PORT || 5000;

if (isProd && !authEnabled() && process.env.ALLOW_NO_AUTH !== 'true') {
  console.error('FATAL: API_KEY is not set. Set API_KEY to a long random value (or ALLOW_NO_AUTH=true to run open, NOT recommended).');
  process.exit(1);
}
if (!authEnabled()) console.warn('WARNING: API_KEY is not set - the API is open to anyone who can reach it.');

// Origins allowed to call the API: the Capacitor Android/iOS WebView, local dev, and CORS_ORIGINS.
const allowedOrigins = new Set([
  'https://localhost', 'http://localhost', 'capacitor://localhost', 'http://localhost:3000',
  ...String(process.env.CORS_ORIGINS || '').split(',').map((s) => s.trim()).filter(Boolean)
]);
const corsOrigin = (origin, cb) => cb(null, !origin || allowedOrigins.has(origin));

const app = express();
if (process.env.TRUST_PROXY) app.set('trust proxy', process.env.TRUST_PROXY === 'true' ? 1 : process.env.TRUST_PROXY);
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: corsOrigin, methods: ['GET', 'POST'] } });
io.use(socketAuth);

app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
app.use(cors({ origin: corsOrigin, allowedHeaders: ['Content-Type', 'x-api-key'] }));
morgan.token('url', (req) => String(req.originalUrl || req.url).replace(/token=[^&]+/, 'token=***'));
app.use(morgan(isProd ? 'combined' : 'dev'));
app.use(express.json({ limit: '50kb' }));
app.use(express.urlencoded({ extended: true, limit: '50kb' }));

fs.ensureDirSync(DOWNLOADS_DIR);

// Rate limit everything under /api
app.use('/api', rateLimit({ windowMs: 60 * 1000, max: Number.parseInt(process.env.RATE_LIMIT_MAX, 10) || 120 }));

// Public: health check and token-protected file download
app.get('/api/health', (_req, res) => res.json({ ok: true, auth: authEnabled() }));
app.use('/api/files', files.publicRouter);

// Everything below needs the API key
app.use('/api', requireApiKey);
app.use('/api/files', files.privateRouter);
app.use('/api/download', require('./routes/download'));
app.use('/api/info', require('./routes/info'));
app.use('/api/formats', require('./routes/formats'));

io.on('connection', (socket) => {
  console.log('Client connected:', socket.id);
  socket.on('disconnect', () => console.log('Client disconnected:', socket.id));
});
app.set('socketio', io);

// Optionally serve the built web UI
const buildDir = path.join(__dirname, '../client/build');
if (isProd && fs.existsSync(path.join(buildDir, 'index.html'))) {
  app.use(express.static(buildDir));
  app.get('*', (_req, res) => res.sendFile(path.join(buildDir, 'index.html')));
}

app.use((err, _req, res, _next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Something went wrong!' });
});

// Delete finished downloads older than RETENTION_HOURS (default 24, 0 = keep forever)
const retentionHours = Number.parseFloat(process.env.RETENTION_HOURS ?? '24');
if (retentionHours > 0) {
  const sweep = async () => {
    try {
      const cutoff = Date.now() - retentionHours * 3600 * 1000;
      for (const entry of await fs.readdir(DOWNLOADS_DIR, { withFileTypes: true })) {
        if (!entry.isFile()) continue;
        const full = path.join(DOWNLOADS_DIR, entry.name);
        const stat = await fs.stat(full);
        if (stat.mtimeMs < cutoff && !(isTempFile(entry.name) && Date.now() - stat.mtimeMs < 3600 * 1000)) {
          await fs.remove(full);
        }
      }
    } catch (e) {
      console.error('Cleanup error:', e.message);
    }
  };
  setInterval(sweep, 30 * 60 * 1000).unref();
  sweep();
}

if (require.main === module) {
  server.listen(PORT, () => {
    console.log(`Server is running on port ${PORT} (${isProd ? 'production' : 'development'})`);
  });
}

module.exports = app;
