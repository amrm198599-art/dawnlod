const express = require('express');
const { runYtdlp, describeError } = require('../utils/ytdlp');
const { parseHttpUrl } = require('../utils/validateUrl');
const router = express.Router();

// GET /api/formats?url=<video_url> - available formats (parsed from yt-dlp JSON, not from table output)
router.get('/', async (req, res) => {
  const parsed = parseHttpUrl(req.query.url);
  if (parsed.error) return res.status(400).json({ error: parsed.error });
  try {
    const { stdout } = await runYtdlp(['--dump-json', '--no-playlist', '--no-warnings', '--', parsed.url]);
    const info = JSON.parse(stdout);
    const all = (info.formats || []).map((f) => {
      const hasVideo = f.vcodec && f.vcodec !== 'none';
      const hasAudio = f.acodec && f.acodec !== 'none';
      return {
        format_code: f.format_id,
        extension: f.ext,
        resolution: f.resolution || (f.height ? `${f.width || '?'}x${f.height}` : 'audio only'),
        height: f.height || null,
        fps: f.fps || null,
        filesize: f.filesize || f.filesize_approx || null,
        note: f.format_note || '',
        type: hasVideo ? 'video' : (hasAudio ? 'audio' : 'other')
      };
    });
    res.json({
      video_formats: all.filter((f) => f.type === 'video'),
      audio_formats: all.filter((f) => f.type === 'audio'),
      all_formats: all
    });
  } catch (error) {
    console.error('Formats error:', error.message);
    res.status(500).json({ error: 'Failed to get format information', details: describeError(error) });
  }
});

// GET /api/formats/quality-presets
router.get('/quality-presets', (_req, res) => {
  res.json({
    video: [
      { value: '2160', label: '4K (2160p)', description: 'Ultra High Definition' },
      { value: '1440', label: '2K (1440p)', description: 'Quad HD' },
      { value: '1080', label: 'Full HD (1080p)', description: 'High Definition' },
      { value: '720', label: 'HD (720p)', description: 'High Definition' },
      { value: '480', label: 'SD (480p)', description: 'Standard Definition' },
      { value: '360', label: 'Low (360p)', description: 'Low Quality' },
      { value: 'best', label: 'Best Available', description: 'Highest quality available' },
      { value: 'worst', label: 'Worst Available', description: 'Lowest quality available' }
    ],
    audio: [
      { value: 'mp3', label: 'MP3', description: 'Standard audio format' },
      { value: 'm4a', label: 'M4A', description: 'High quality audio' },
      { value: 'wav', label: 'WAV', description: 'Uncompressed audio' },
      { value: 'flac', label: 'FLAC', description: 'Lossless audio' },
      { value: 'ogg', label: 'OGG', description: 'Open source audio' },
      { value: 'best', label: 'Best Available', description: 'Keep original audio codec' }
    ]
  });
});

module.exports = router;
