const express = require('express');
const { runYtdlp, describeError } = require('../utils/ytdlp');
const { parseHttpUrl } = require('../utils/validateUrl');
const router = express.Router();

// GET /api/info?url=<video_url> - video metadata
router.get('/', async (req, res) => {
  const parsed = parseHttpUrl(req.query.url);
  if (parsed.error) return res.status(400).json({ error: parsed.error });
  try {
    const { stdout } = await runYtdlp(['--dump-json', '--no-playlist', '--no-warnings', '--', parsed.url]);
    const v = JSON.parse(stdout);
    res.json({
      id: v.id,
      title: v.title,
      description: typeof v.description === 'string' ? v.description.slice(0, 1000) : '',
      duration: v.duration,
      uploader: v.uploader,
      upload_date: v.upload_date,
      view_count: v.view_count,
      thumbnail: v.thumbnail,
      webpage_url: v.webpage_url,
      extractor: v.extractor
    });
  } catch (error) {
    console.error('Info error:', error.message);
    res.status(500).json({ error: 'Failed to get video information', details: describeError(error) });
  }
});

// GET /api/info/playlist?url=<playlist_url> - playlist entries (max 200)
router.get('/playlist', async (req, res) => {
  const parsed = parseHttpUrl(req.query.url);
  if (parsed.error) return res.status(400).json({ error: parsed.error });
  try {
    const { stdout } = await runYtdlp(
      ['--flat-playlist', '--dump-json', '--playlist-end', '200', '--no-warnings', '--', parsed.url],
      { timeoutMs: 90000 }
    );
    const entries = stdout.split('\n').filter((l) => l.trim()).map((l) => JSON.parse(l));
    res.json({
      entries: entries.map((e) => ({ id: e.id, title: e.title, url: e.url, duration: e.duration, uploader: e.uploader }))
    });
  } catch (error) {
    console.error('Playlist error:', error.message);
    res.status(500).json({ error: 'Failed to get playlist information', details: describeError(error) });
  }
});

module.exports = router;
