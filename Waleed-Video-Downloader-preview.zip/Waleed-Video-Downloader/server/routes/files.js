const express = require('express');
const crypto = require('crypto');
const fs = require('fs-extra');
const { resolveDownload } = require('../utils/paths');

const TOKEN_TTL_MS = 2 * 60 * 1000;
const tokens = new Map();

function issueToken(filename) {
  const token = crypto.randomBytes(24).toString('hex');
  tokens.set(token, { filename, exp: Date.now() + TOKEN_TTL_MS });
  return token;
}

function checkToken(token, filename) {
  const entry = typeof token === 'string' ? tokens.get(token) : null;
  if (!entry) return false;
  if (entry.exp < Date.now()) {
    tokens.delete(token);
    return false;
  }
  return entry.filename === filename;
}

setInterval(() => {
  const now = Date.now();
  for (const [t, e] of tokens) if (e.exp < now) tokens.delete(t);
}, 60 * 1000).unref();

// Public: protected by a short-lived single-file token (so a browser/WebView can fetch it).
const publicRouter = express.Router();
publicRouter.get('/:filename', async (req, res) => {
  const filename = req.params.filename;
  const filePath = resolveDownload(filename);
  if (!filePath) return res.status(400).json({ error: 'Invalid filename.' });
  if (!checkToken(req.query.token, filename)) {
    return res.status(401).json({ error: 'Download link expired or invalid.' });
  }
  if (!(await fs.pathExists(filePath))) return res.status(404).json({ error: 'File not found.' });
  return res.download(filePath, filename, (err) => {
    if (err && !res.headersSent) res.status(500).json({ error: 'Failed to send file.' });
  });
});

// Private (needs API key): issue a token for one file.
const privateRouter = express.Router();
privateRouter.post('/:filename/token', async (req, res) => {
  const filename = req.params.filename;
  const filePath = resolveDownload(filename);
  if (!filePath) return res.status(400).json({ error: 'Invalid filename.' });
  if (!(await fs.pathExists(filePath))) return res.status(404).json({ error: 'File not found.' });
  return res.json({ token: issueToken(filename), expiresInSeconds: TOKEN_TTL_MS / 1000 });
});

module.exports = { publicRouter, privateRouter, issueToken, checkToken };
