const express = require('express');
const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs-extra');
const { DOWNLOADS_DIR, resolveDownload, isTempFile } = require('../utils/paths');
const { parseHttpUrl } = require('../utils/validateUrl');
const { ytdlpBinary } = require('../utils/ytdlp');
const { rateLimit } = require('../utils/rateLimit');

const router = express.Router();

const AUDIO_FORMATS = new Set(['best', 'mp3', 'm4a', 'wav', 'flac', 'ogg', 'opus']);
const QUALITIES = new Set(['best', 'worst', '2160', '1440', '1080', '720', '480', '360', '240', '144']);
const MAX_CONCURRENT = Math.max(1, Number.parseInt(process.env.MAX_CONCURRENT_DOWNLOADS, 10) || 3);
let activeDownloads = 0;

const startLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: Number.parseInt(process.env.DOWNLOAD_RATE_LIMIT, 10) || 15,
  message: 'Too many download requests. Try again in a minute.'
});

function parseProgress(text, downloadInfo, io) {
  // yt-dlp writes progress to stderr/stdout, and chunks can split a line.
  const matches = text.match(/(?:\[download\]\s*)?(\d{1,3}(?:\.\d+)?)%/g) || [];
  if (!matches.length) return;
  const last = matches[matches.length - 1].match(/(\d{1,3}(?:\.\d+)?)%/);
  if (!last) return;
  const value = Math.max(0, Math.min(100, Number.parseFloat(last[1])));
  if (Number.isFinite(value)) {
    downloadInfo.progress = value;
    downloadInfo.status = 'downloading';
    if (io) io.emit('download-progress', { ...downloadInfo });
  }
}

router.post('/', startLimiter, async (req, res) => {
  const { url, format, quality, audioOnly } = req.body || {};
  const io = req.app.get('socketio');

  const parsed = parseHttpUrl(url);
  if (parsed.error) return res.status(400).json({ error: parsed.error });

  const isAudio = audioOnly === true || audioOnly === 'true';
  const audioFormat = String(format || 'mp3').toLowerCase();
  if (isAudio && !AUDIO_FORMATS.has(audioFormat)) {
    return res.status(400).json({ error: 'Unsupported audio format.' });
  }
  const requestedQuality = String(quality || 'best').toLowerCase();
  if (!isAudio && !QUALITIES.has(requestedQuality)) {
    return res.status(400).json({ error: 'Unsupported video quality.' });
  }
  if (activeDownloads >= MAX_CONCURRENT) {
    return res.status(429).json({ error: `Server is busy (${MAX_CONCURRENT} downloads running). Try again shortly.` });
  }

  try {
    await fs.ensureDir(DOWNLOADS_DIR);
    const args = [
      '--no-playlist',
      '--newline',
      '--progress',
      '--no-mtime',
      '--print', 'after_move:filepath',
      '--output', path.join(DOWNLOADS_DIR, '%(title).180B [%(id)s].%(ext)s')
    ];

    if (isAudio) {
      args.push('-f', 'bestaudio/best', '-x', '--audio-format', audioFormat);
    } else if (requestedQuality === 'worst') {
      args.push('-f', 'worstvideo+worstaudio/worst');
    } else if (requestedQuality !== 'best') {
      args.push('-f', `bestvideo[height<=${requestedQuality}]+bestaudio/best[height<=${requestedQuality}]/best[height<=${requestedQuality}]`);
    } else {
      args.push('-f', 'bestvideo+bestaudio/best');
    }
    args.push('--', parsed.url);

    const downloadId = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    const downloadInfo = { id: downloadId, url: parsed.url, status: 'starting', progress: 0, filename: '', error: null };

    let stderrTail = '';
    let stdoutBuffer = '';
    let stderrBuffer = '';
    let settled = false;
    let released = false;
    const release = () => {
      if (released) return;
      released = true;
      activeDownloads = Math.max(0, activeDownloads - 1);
    };

    activeDownloads += 1;
    let ytdlp;
    try {
      ytdlp = spawn(ytdlpBinary(), args, { windowsHide: true });
    } catch (spawnError) {
      release();
      throw spawnError;
    }
    if (io) io.emit('download-start', { ...downloadInfo });

    const fail = (message) => {
      release();
      if (settled) return;
      settled = true;
      downloadInfo.status = 'error';
      downloadInfo.error = String(message || 'Download failed').slice(-1500);
      if (io) io.emit('download-error', { ...downloadInfo });
    };

    const handleOutput = (chunk, isStderr) => {
      const text = chunk.toString();
      if (isStderr) {
        stderrTail = (stderrTail + text).slice(-3000);
        stderrBuffer += text;
      } else {
        stdoutBuffer += text;
      }
      const lines = (isStderr ? stderrBuffer : stdoutBuffer).split(/\r?\n/);
      if (isStderr) stderrBuffer = lines.pop() || '';
      else stdoutBuffer = lines.pop() || '';
      for (const line of lines) {
        const clean = line.trim();
        if (!clean) continue;
        const destination = clean.match(/^\[download\]\s+Destination:\s+(.+)$/);
        const moved = clean.match(/^(.+\.(?:mp4|mkv|webm|mov|mp3|m4a|wav|flac|ogg|opus))$/i);
        if (destination) downloadInfo.filename = path.basename(destination[1]);
        else if (moved && clean.startsWith(DOWNLOADS_DIR)) downloadInfo.filename = path.basename(clean);
        parseProgress(clean, downloadInfo, io);
      }
      // Also inspect the raw chunk in case yt-dlp uses carriage-return updates.
      parseProgress(text, downloadInfo, io);
    };

    ytdlp.stdout.on('data', (chunk) => handleOutput(chunk, false));
    ytdlp.stderr.on('data', (chunk) => handleOutput(chunk, true));
    ytdlp.on('error', (error) => {
      fail(error.code === 'ENOENT'
        ? 'yt-dlp was not found. Install yt-dlp on the server and make sure it is on PATH.'
        : error.message);
    });
    ytdlp.on('close', (code) => {
      release();
      if (settled) return;
      if (code === 0) {
        settled = true;
        downloadInfo.status = 'completed';
        downloadInfo.progress = 100;
        if (io) io.emit('download-complete', { ...downloadInfo });
      } else {
        fail(stderrTail.trim() || `yt-dlp exited with code ${code}`);
      }
    });

    return res.json({ success: true, downloadId, message: 'Download started' });
  } catch (error) {
    console.error('Download setup error:', error);
    return res.status(500).json({ error: 'Could not start the download.', details: error.message });
  }
});

router.get('/list', async (_req, res) => {
  try {
    await fs.ensureDir(DOWNLOADS_DIR);
    const entries = await fs.readdir(DOWNLOADS_DIR, { withFileTypes: true });
    const files = entries.filter((e) => e.isFile() && !isTempFile(e.name));
    const fileList = await Promise.all(files.map(async (entry) => {
      const stats = await fs.stat(path.join(DOWNLOADS_DIR, entry.name));
      return { name: entry.name, size: stats.size, createdAt: stats.birthtime, modifiedAt: stats.mtime };
    }));
    res.json(fileList.sort((a, b) => b.modifiedAt - a.modifiedAt));
  } catch (error) {
    console.error('Error listing files:', error);
    res.status(500).json({ error: 'Failed to list downloaded files.' });
  }
});

router.delete('/:filename', async (req, res) => {
  try {
    const filePath = resolveDownload(req.params.filename);
    if (!filePath) return res.status(400).json({ error: 'Invalid filename.' });
    if (!(await fs.pathExists(filePath))) return res.status(404).json({ error: 'File not found.' });
    await fs.remove(filePath);
    return res.json({ success: true, message: 'File deleted successfully.' });
  } catch (error) {
    console.error('Error deleting file:', error);
    return res.status(500).json({ error: 'Failed to delete file.' });
  }
});

module.exports = router;
