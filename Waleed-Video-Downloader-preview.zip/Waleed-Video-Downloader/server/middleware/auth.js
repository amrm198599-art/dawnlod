const crypto = require('crypto');

function safeEqual(a, b) {
  const ha = crypto.createHash('sha256').update(String(a)).digest();
  const hb = crypto.createHash('sha256').update(String(b)).digest();
  return crypto.timingSafeEqual(ha, hb);
}

const authEnabled = () => Boolean(process.env.API_KEY);

function requireApiKey(req, res, next) {
  if (!authEnabled()) return next();
  const key = req.get('x-api-key');
  if (key && safeEqual(key, process.env.API_KEY)) return next();
  return res.status(401).json({ error: 'Unauthorized: missing or invalid API key.' });
}

function socketAuth(socket, next) {
  if (!authEnabled()) return next();
  const key = socket.handshake.auth && socket.handshake.auth.key;
  if (key && safeEqual(key, process.env.API_KEY)) return next();
  return next(new Error('unauthorized'));
}

module.exports = { requireApiKey, socketAuth, authEnabled, safeEqual };
