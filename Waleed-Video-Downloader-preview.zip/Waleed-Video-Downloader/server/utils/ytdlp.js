const { spawn } = require('child_process');

const ytdlpBinary = () => process.env.YTDLP_PATH || 'yt-dlp';

// Runs yt-dlp, resolves with { stdout, stderr }, rejects with a descriptive Error.
function runYtdlp(args, { timeoutMs = 60000, maxBytes = 20 * 1024 * 1024 } = {}) {
  return new Promise((resolve, reject) => {
    let child;
    try {
      child = spawn(ytdlpBinary(), args, { windowsHide: true });
    } catch (e) {
      return reject(e);
    }
    let stdout = '';
    let stderr = '';
    let done = false;
    const finish = (fn, value) => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      fn(value);
    };
    const timer = setTimeout(() => {
      child.kill('SIGKILL');
      finish(reject, Object.assign(new Error('yt-dlp timed out.'), { code: 'ETIMEDOUT' }));
    }, timeoutMs);
    child.stdout.on('data', (d) => {
      stdout += d;
      if (stdout.length > maxBytes) {
        child.kill('SIGKILL');
        finish(reject, new Error('yt-dlp output was too large.'));
      }
    });
    child.stderr.on('data', (d) => { stderr = (stderr + d).slice(-4000); });
    child.on('error', (e) => finish(reject, e));
    child.on('close', (code) => {
      if (code === 0) finish(resolve, { stdout, stderr });
      else finish(reject, Object.assign(new Error(stderr.trim() || `yt-dlp exited with code ${code}`), { code: 'EXIT' }));
    });
  });
}

function describeError(e) {
  if (e && e.code === 'ENOENT') return 'yt-dlp is not installed on the server or is not on PATH.';
  if (e && e.code === 'ETIMEDOUT') return 'The site took too long to respond.';
  return String((e && e.message) || 'yt-dlp failed').slice(-1500);
}

module.exports = { runYtdlp, describeError, ytdlpBinary };
