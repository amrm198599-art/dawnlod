const net = require('net');

function isPrivateHost(hostname) {
  const h = String(hostname).toLowerCase().replace(/^\[|\]$/g, '');
  if (h === 'localhost' || h.endsWith('.localhost') || h.endsWith('.local') || h.endsWith('.internal')) return true;
  const version = net.isIP(h);
  if (version === 4) {
    const [a, b] = h.split('.').map(Number);
    return a === 0 || a === 10 || a === 127 || (a === 169 && b === 254) ||
      (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || (a === 100 && b >= 64 && b <= 127);
  }
  if (version === 6) {
    return h === '::1' || h === '::' || h.startsWith('fc') || h.startsWith('fd') || h.startsWith('fe80') || h.startsWith('::ffff:');
  }
  return false;
}

// Returns { url: 'https://...' } or { error: '...' }.
function parseHttpUrl(input) {
  if (typeof input !== 'string' || !input.trim()) return { error: 'URL is required' };
  if (input.length > 2048) return { error: 'URL is too long.' };
  let parsed;
  try {
    parsed = new URL(input.trim());
  } catch (_) {
    return { error: 'Please provide a valid URL.' };
  }
  if (!['http:', 'https:'].includes(parsed.protocol) || !parsed.hostname) {
    return { error: 'Only HTTP and HTTPS URLs are supported.' };
  }
  if (process.env.ALLOW_PRIVATE_URLS !== 'true' && isPrivateHost(parsed.hostname)) {
    return { error: 'Local and private network addresses are not allowed.' };
  }
  return { url: parsed.toString() };
}

module.exports = { parseHttpUrl, isPrivateHost };
