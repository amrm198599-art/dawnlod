const path = require('path');

const DOWNLOADS_DIR = path.resolve(process.env.DOWNLOADS_DIR || path.join(__dirname, '../../downloads'));
const TEMP_SUFFIXES = ['.part', '.ytdl', '.temp', '.tmp'];

function isTempFile(name) {
  const lower = name.toLowerCase();
  return TEMP_SUFFIXES.some((s) => lower.endsWith(s)) || /\.f\d+\.[a-z0-9]+$/i.test(lower);
}

// Returns an absolute path inside DOWNLOADS_DIR, or null if the name is unsafe.
function resolveDownload(name) {
  if (typeof name !== 'string' || !name) return null;
  const base = path.basename(name);
  if (base !== name || base === '.' || base === '..' || base.includes('\0') || base.includes('\\')) return null;
  const full = path.resolve(DOWNLOADS_DIR, base);
  return full.startsWith(DOWNLOADS_DIR + path.sep) ? full : null;
}

module.exports = { DOWNLOADS_DIR, resolveDownload, isTempFile };
