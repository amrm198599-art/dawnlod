const test = require('node:test');
const assert = require('node:assert');
const { parseHttpUrl, isPrivateHost } = require('../utils/validateUrl');
const { resolveDownload, isTempFile, DOWNLOADS_DIR } = require('../utils/paths');
const { rateLimit } = require('../utils/rateLimit');
const { safeEqual } = require('../middleware/auth');

test('parseHttpUrl accepts public http(s) URLs', () => {
  assert.ok(parseHttpUrl('https://vimeo.com/147365861').url);
  assert.ok(parseHttpUrl('http://example.com/a?b=1').url);
});

test('parseHttpUrl rejects bad input', () => {
  for (const bad of ['', 'not a url', 'ftp://x.com/a', 'file:///etc/passwd', 'javascript:alert(1)', 42, null]) {
    assert.ok(parseHttpUrl(bad).error, `should reject ${bad}`);
  }
});

test('parseHttpUrl blocks private hosts', () => {
  for (const h of ['http://localhost:5000', 'http://127.0.0.1', 'http://10.0.0.5', 'http://192.168.1.1',
    'http://172.20.0.1', 'http://169.254.169.254/latest', 'http://[::1]/', 'http://printer.local']) {
    assert.ok(parseHttpUrl(h).error, `should block ${h}`);
  }
  assert.equal(isPrivateHost('8.8.8.8'), false);
  assert.equal(isPrivateHost('172.32.0.1'), false);
});

test('resolveDownload rejects path traversal', () => {
  for (const bad of ['../x', '..', '.', 'a/b', '..\\x', '', null, 'a\0b']) {
    assert.equal(resolveDownload(bad), null, `should reject ${JSON.stringify(bad)}`);
  }
  assert.ok(resolveDownload('video [abc].mp4').startsWith(DOWNLOADS_DIR));
});

test('isTempFile detects yt-dlp partials', () => {
  assert.ok(isTempFile('a.mp4.part'));
  assert.ok(isTempFile('a.f137.mp4'));
  assert.ok(isTempFile('a.mp4.ytdl'));
  assert.equal(isTempFile('a [id].mp4'), false);
});

test('rateLimit returns 429 after max', () => {
  const limiter = rateLimit({ windowMs: 60000, max: 2 });
  const res = () => ({ code: 200, set() {}, status(c) { this.code = c; return this; }, json() { return this; } });
  const req = { ip: '1.2.3.4' };
  let passed = 0;
  const r = [res(), res(), res()];
  r.forEach((x) => limiter(req, x, () => { passed += 1; }));
  assert.equal(passed, 2);
  assert.equal(r[2].code, 429);
});

test('safeEqual compares keys', () => {
  assert.ok(safeEqual('abc', 'abc'));
  assert.equal(safeEqual('abc', 'abd'), false);
  assert.equal(safeEqual('abc', 'abcd'), false);
});
