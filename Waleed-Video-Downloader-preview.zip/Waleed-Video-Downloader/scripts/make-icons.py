#!/usr/bin/env python3
"""Regenerate every app icon from one square PNG.  Usage: python3 scripts/make-icons.py resources/icon.png
Needs Pillow (pip install pillow). Output is committed, CI does not run this."""
import os, sys
from PIL import Image, ImageDraw

src = Image.open(sys.argv[1] if len(sys.argv) > 1 else 'resources/icon.png').convert('RGB')
S = src.size[0]
root = 'resources/android/res'
dens = {'mdpi': (48, 108), 'hdpi': (72, 162), 'xhdpi': (96, 216), 'xxhdpi': (144, 324), 'xxxhdpi': (192, 432)}
LEFT, RIGHT = (3, 12, 38), (0, 41, 110)   # background gradient colours sampled from the artwork


def gradient(size):
    g = Image.new('RGBA', (size, size))
    px = g.load()
    for x in range(size):
        t = x / (size - 1)
        c = tuple(int(LEFT[i] + (RIGHT[i] - LEFT[i]) * t) for i in range(3)) + (255,)
        for y in range(size):
            px[x, y] = c
    return g


def with_mask(img, shape, frac=0.22):
    s = img.size[0]
    m = Image.new('L', (s * 4, s * 4), 0)
    d = ImageDraw.Draw(m)
    if shape == 'circle':
        d.ellipse([0, 0, s * 4 - 1, s * 4 - 1], fill=255)
    else:
        d.rounded_rectangle([0, 0, s * 4 - 1, s * 4 - 1], radius=int(s * 4 * frac), fill=255)
    out = img.convert('RGBA')
    out.putalpha(m.resize((s, s), Image.LANCZOS))
    return out


# glowing rounded square cut out of the opaque artwork (used as adaptive-icon foreground)
inset, rad = 58, 300
fm = Image.new('L', (S * 2, S * 2), 0)
ImageDraw.Draw(fm).rounded_rectangle([inset * 2, inset * 2, (S - inset) * 2, (S - inset) * 2], radius=rad * 2, fill=255)
fg_full = src.convert('RGBA')
fg_full.putalpha(fm.resize((S, S), Image.LANCZOS))
fg_full = fg_full.crop((inset - 6, inset - 6, S - inset + 6, S - inset + 6))

for d, (leg, ad) in dens.items():
    p = f'{root}/mipmap-{d}'
    os.makedirs(p, exist_ok=True)
    base = src.resize((leg, leg), Image.LANCZOS)
    with_mask(base, 'rounded').save(f'{p}/ic_launcher.png')
    # round legacy icon: artwork a bit smaller on the gradient so nothing important is clipped
    rb = gradient(leg)
    inner = int(leg * 0.88)
    art = base.resize((inner, inner), Image.LANCZOS).convert('RGBA')
    rb.paste(art, ((leg - inner) // 2, (leg - inner) // 2))
    with_mask(rb, 'circle').save(f'{p}/ic_launcher_round.png')
    canvas = Image.new('RGBA', (ad, ad), (0, 0, 0, 0))
    t = int(ad * 0.64)  # stays inside the adaptive-icon safe zone
    f = fg_full.resize((t, t), Image.LANCZOS)
    canvas.paste(f, ((ad - t) // 2, (ad - t) // 2), f)
    canvas.save(f'{p}/wvd_foreground.png')

os.makedirs(f'{root}/mipmap-anydpi-v26', exist_ok=True)
os.makedirs(f'{root}/drawable', exist_ok=True)
adaptive = '''<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@drawable/wvd_icon_bg"/>
    <foreground android:drawable="@mipmap/wvd_foreground"/>
</adaptive-icon>
'''
for n in ('ic_launcher.xml', 'ic_launcher_round.xml'):
    open(f'{root}/mipmap-anydpi-v26/{n}', 'w').write(adaptive)
open(f'{root}/drawable/wvd_icon_bg.xml', 'w').write('''<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android" android:shape="rectangle">
    <gradient android:type="linear" android:angle="0" android:startColor="#030C26" android:endColor="#00296E"/>
</shape>
''')

pub = 'client/public'
if os.path.isdir(pub):
    with_mask(src.resize((512, 512), Image.LANCZOS), 'rounded').save(f'{pub}/logo512.png')
    with_mask(src.resize((192, 192), Image.LANCZOS), 'rounded').save(f'{pub}/logo192.png')
    src.resize((64, 64), Image.LANCZOS).save(f'{pub}/favicon.ico', sizes=[(16, 16), (32, 32), (48, 48), (64, 64)])
print('icons generated')
