#!/usr/bin/env bash
# Creates a release keystore and prints the 4 values to save as GitHub Actions secrets.
# Usage: ./scripts/generate-keystore.sh [alias] [output-file]
set -euo pipefail

ALIAS="${1:-waleed}"
OUT="${2:-waleed-release.keystore}"

command -v keytool >/dev/null || { echo "keytool not found. Install a JDK (17+)."; exit 1; }
[ -e "$OUT" ] && { echo "Refusing to overwrite existing $OUT"; exit 1; }

PASS="$(LC_ALL=C tr -dc 'A-Za-z0-9' </dev/urandom | head -c 24 || true)"
[ "${#PASS}" -eq 24 ] || { echo "Could not generate a password"; exit 1; }

keytool -genkeypair -noprompt \
  -keystore "$OUT" -alias "$ALIAS" \
  -keyalg RSA -keysize 4096 -validity 10000 \
  -storepass "$PASS" -keypass "$PASS" \
  -dname "CN=Waleed Video Downloader, O=Waleed, C=EG"

B64="$(base64 < "$OUT" | tr -d '\n')"

cat <<MSG

Keystore created: $OUT

Add these in GitHub -> Settings -> Secrets and variables -> Actions -> Secrets:

  ANDROID_KEYSTORE_PASSWORD = $PASS
  ANDROID_KEY_ALIAS         = $ALIAS
  ANDROID_KEY_PASSWORD      = $PASS
  ANDROID_KEYSTORE_BASE64   = (the long text below)

$B64

IMPORTANT
  * Back up $OUT and the password somewhere safe (password manager). If you lose
    them you can never publish updates to the same app.
  * Never commit the keystore to git (it is in .gitignore).
MSG
