# License notice

- The app code in this repository was written for this project.
- The Android build bundles **youtubedl-android** (https://github.com/yausername/youtubedl-android, GPL-3.0),
  **yt-dlp** (Unlicense), **FFmpeg** (LGPL/GPL build) and **Python** (PSF). Because of the GPL-3.0 library, an
  Android APK/AAB you distribute must be offered together with its **complete source code under GPL-3.0**
  (publishing this repository publicly is enough).
- `LICENSE` (WTFPL) applies to this repository's own code only; the combined APK is GPL-3.0.
- Idea and UX inspired by [Seal](https://github.com/JunkFood02/Seal) (GPL-3.0). No Seal source code is copied.
