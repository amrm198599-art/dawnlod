import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';

export type Lang = 'ar' | 'en';

const en: Record<string, string> = {
  eyebrow: 'FAST • SIMPLE • HIGH QUALITY',
  heroA: 'Your videos,',
  heroB: 'ready to go.',
  heroSub: 'Paste a video link, choose your quality, and manage your downloads in one clean workspace.',
  feat1: 'Easy link input',
  feat2: 'Quality options',
  feat3: 'Download manager',
  footer: 'Download responsibly and respect creators’ rights.',

  'form.title': 'Download Video/Audio',
  'form.urlLabel': 'Video URL',
  'form.urlPlaceholder': 'Paste a video link (YouTube, TikTok, Facebook, Instagram…)',
  'form.getInfo': 'Get Info',
  'form.download': 'Download',
  'form.advanced': 'Advanced options',
  'form.options': 'Download Options',
  'form.audioOnly': 'Audio only',
  'form.audioFormat': 'Audio format',
  'form.videoQuality': 'Video quality',
  'form.enterUrl': 'Please enter a link',
  'form.started': 'Download started. Follow it in Download Progress below.',
  'form.info': 'Video information',
  'form.by': 'by',
  'form.duration': 'Duration',
  'form.views': 'Views',

  'vq.best': 'Best available',
  'vq.2160': '4K (2160p)',
  'vq.1440': '2K (1440p)',
  'vq.1080': 'Full HD (1080p)',
  'vq.720': 'HD (720p)',
  'vq.480': 'SD (480p)',
  'vq.360': 'Low (360p)',
  'vq.worst': 'Lowest available',
  'af.mp3': 'MP3',
  'af.m4a': 'M4A',
  'af.wav': 'WAV (uncompressed)',
  'af.flac': 'FLAC (lossless)',
  'af.ogg': 'OGG',
  'af.best': 'Best (original)',

  'progress.title': 'Download Progress',
  'progress.active': 'Active Downloads',
  'progress.recent': 'Recent Downloads',
  'progress.preparing': 'Preparing download…',
  'progress.unknown': 'Unknown file',
  'progress.error': 'Error',
  'status.starting': 'starting',
  'status.downloading': 'downloading',
  'status.completed': 'done',
  'status.error': 'failed',

  'history.title': 'Download History',
  'history.refresh': 'Refresh',
  'history.empty': 'No downloaded files yet',
  'history.size': 'Size',
  'history.downloaded': 'Downloaded',
  'history.save': 'Save to device',
  'history.open': 'Open',
  'history.delete': 'Delete',
  'history.savedIn': 'Saved in: Downloads/WaleedDownloader',
  'type.video': 'video',
  'type.audio': 'audio',
  'type.unknown': 'file',

  'header.online': 'Server online',
  'header.offline': 'Server offline',
  'header.needKey': 'API key needed',
  'header.checking': 'Checking server',
  'header.offlineAlert': 'Download server is unreachable. Check the server address in Settings (⚙) and that the server is running.',
  'header.keyAlert': 'The server needs an API key. Open Settings (⚙) and enter it.',
  'settings.title': 'Settings',
  'settings.server': 'Server address',
  'settings.apiKey': 'API key',
  'settings.keyHelp': 'Stored only on this device.',
  'settings.cancel': 'Cancel',
  'settings.save': 'Save',
  'settings.close': 'Close',
  'settings.language': 'Language',
  'settings.update': 'Update download engine',
  'settings.updating': 'Updating…',
  'settings.updated': 'Engine updated.',
  'settings.updateFailed': 'Update failed. Check your internet connection.',
  'settings.engineHint': 'If downloads stop working, update the engine (sites change often).',

  'err.unauthorized': 'Unauthorized. Enter the correct API key in Settings (⚙).',
  'err.tooMany': 'Too many requests. Try again shortly.',
  'err.network': 'Cannot reach the server. Check the server address in Settings (⚙).',
  'err.invalid_url': 'Please provide a valid link.',
  'err.info': 'Failed to fetch video information',
  'err.download': 'Download failed',
  'err.load': 'Failed to load files',
  'err.delete': 'Failed to delete file',
  'err.save': 'Failed to prepare the download',
  'err.open': 'No app on your phone can open this file',
  'hint.update': 'YouTube rejected the request. This usually means the download engine is outdated. Update it, then try again.',
  'hint.signin': 'YouTube asked for a sign-in (often caused by a VPN or heavy use). Turn off the VPN, update the engine, then try again.',
  'hint.network': 'Network problem. Check your internet connection and try again.',
  'hint.unavailable': 'This video is private, removed, or not available in your region.',
  'hint.retry': 'Now try the download again.',
  'err.noEngine': 'This APK was built without the download engine. Rebuild it with the latest workflow (see ANDROID-BUILD-AR.md).',
};

const ar: Record<string, string> = {
  eyebrow: 'سريع • بسيط • جودة عالية',
  heroA: 'فيديوهاتك،',
  heroB: 'جاهزة للتحميل.',
  heroSub: 'الصق رابط الفيديو، اختر الجودة، وتابع تحميلاتك في مكان واحد منظم.',
  feat1: 'لصق الرابط بسهولة',
  feat2: 'اختيارات الجودة',
  feat3: 'مدير التحميلات',
  footer: 'حمّل بمسؤولية واحترم حقوق صُنّاع المحتوى.',

  'form.title': 'تحميل فيديو / صوت',
  'form.urlLabel': 'رابط الفيديو',
  'form.urlPlaceholder': 'الصق رابط الفيديو (يوتيوب، تيك توك، فيسبوك، إنستجرام…)',
  'form.getInfo': 'معلومات',
  'form.download': 'تحميل',
  'form.advanced': 'خيارات متقدمة',
  'form.options': 'خيارات التحميل',
  'form.audioOnly': 'صوت فقط',
  'form.audioFormat': 'صيغة الصوت',
  'form.videoQuality': 'جودة الفيديو',
  'form.enterUrl': 'من فضلك أدخل الرابط',
  'form.started': 'بدأ التحميل. تابعه في قسم تقدّم التحميل بالأسفل.',
  'form.info': 'معلومات الفيديو',
  'form.by': 'بواسطة',
  'form.duration': 'المدة',
  'form.views': 'المشاهدات',

  'vq.best': 'أفضل جودة متاحة',
  'vq.2160': '4K (2160p)',
  'vq.1440': '2K (1440p)',
  'vq.1080': 'فل إتش دي (1080p)',
  'vq.720': 'إتش دي (720p)',
  'vq.480': 'عادية (480p)',
  'vq.360': 'منخفضة (360p)',
  'vq.worst': 'أقل جودة',
  'af.mp3': 'MP3',
  'af.m4a': 'M4A',
  'af.wav': 'WAV (غير مضغوط)',
  'af.flac': 'FLAC (بدون فقد)',
  'af.ogg': 'OGG',
  'af.best': 'الأفضل (الأصلي)',

  'progress.title': 'تقدّم التحميل',
  'progress.active': 'التحميلات الجارية',
  'progress.recent': 'آخر التحميلات',
  'progress.preparing': 'جاري التجهيز…',
  'progress.unknown': 'ملف غير معروف',
  'progress.error': 'خطأ',
  'status.starting': 'بدأ',
  'status.downloading': 'جاري التحميل',
  'status.completed': 'تم',
  'status.error': 'فشل',

  'history.title': 'سجل التحميلات',
  'history.refresh': 'تحديث',
  'history.empty': 'لا توجد ملفات محمّلة بعد',
  'history.size': 'الحجم',
  'history.downloaded': 'تاريخ التحميل',
  'history.save': 'حفظ على الجهاز',
  'history.open': 'فتح',
  'history.delete': 'حذف',
  'history.savedIn': 'محفوظة في: التنزيلات/WaleedDownloader',
  'type.video': 'فيديو',
  'type.audio': 'صوت',
  'type.unknown': 'ملف',

  'header.online': 'السيرفر متصل',
  'header.offline': 'السيرفر غير متصل',
  'header.needKey': 'مطلوب مفتاح API',
  'header.checking': 'جاري فحص السيرفر',
  'header.offlineAlert': 'لا يمكن الوصول لسيرفر التحميل. تحقق من العنوان في الإعدادات (⚙) ومن أن السيرفر شغال.',
  'header.keyAlert': 'السيرفر يحتاج مفتاح API. افتح الإعدادات (⚙) وأدخله.',
  'settings.title': 'الإعدادات',
  'settings.server': 'عنوان السيرفر',
  'settings.apiKey': 'مفتاح API',
  'settings.keyHelp': 'محفوظ على هذا الجهاز فقط.',
  'settings.cancel': 'إلغاء',
  'settings.save': 'حفظ',
  'settings.close': 'إغلاق',
  'settings.language': 'اللغة',
  'settings.update': 'تحديث محرّك التحميل',
  'settings.updating': 'جاري التحديث…',
  'settings.updated': 'تم تحديث المحرّك.',
  'settings.updateFailed': 'فشل التحديث. تأكد من اتصالك بالإنترنت.',
  'settings.engineHint': 'لو التحميل وقف، حدّث المحرّك (المواقع بتتغير كتير).',

  'err.unauthorized': 'غير مصرّح. أدخل مفتاح API الصحيح في الإعدادات (⚙).',
  'err.tooMany': 'طلبات كتير. حاول بعد شوية.',
  'err.network': 'لا يمكن الوصول للسيرفر. تحقق من العنوان في الإعدادات (⚙).',
  'err.invalid_url': 'من فضلك أدخل رابطًا صحيحًا.',
  'err.info': 'تعذّر جلب معلومات الفيديو',
  'err.download': 'فشل التحميل',
  'err.load': 'تعذّر تحميل قائمة الملفات',
  'err.delete': 'تعذّر حذف الملف',
  'err.save': 'تعذّر تجهيز التحميل',
  'err.open': 'لا يوجد تطبيق على هاتفك يفتح هذا الملف',
  'hint.update': 'يوتيوب رفض الطلب. غالبًا محرّك التحميل قديم. حدّثه ثم جرّب مرة تانية.',
  'hint.signin': 'يوتيوب طلب تسجيل دخول (غالبًا بسبب VPN أو كثرة الطلبات). اقفل الـ VPN وحدّث المحرّك ثم جرّب تاني.',
  'hint.network': 'مشكلة في الشبكة. تأكد من اتصالك بالإنترنت وجرّب تاني.',
  'hint.unavailable': 'الفيديو ده خاص أو محذوف أو غير متاح في بلدك.',
  'hint.retry': 'جرّب التحميل تاني دلوقتي.',
  'err.noEngine': 'الـ APK ده اتبنى من غير محرّك التحميل. أعد البناء بآخر workflow (راجع ANDROID-BUILD-AR.md).',
};

const dict: Record<Lang, Record<string, string>> = { en, ar };
const STORAGE = 'wvd_lang';

function initialLang(): Lang {
  try {
    const saved = window.localStorage.getItem(STORAGE);
    if (saved === 'ar' || saved === 'en') return saved;
  } catch {
    /* ignore */
  }
  return (navigator.language || 'en').toLowerCase().startsWith('ar') ? 'ar' : 'en';
}

interface I18nValue {
  lang: Lang;
  dir: 'rtl' | 'ltr';
  setLang: (l: Lang) => void;
  t: (key: string) => string;
}

const I18nContext = createContext<I18nValue | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [lang, setLangState] = useState<Lang>(initialLang);
  const dir = lang === 'ar' ? 'rtl' : 'ltr';

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = dir;
  }, [lang, dir]);

  const value = useMemo<I18nValue>(() => ({
    lang,
    dir,
    setLang: (l: Lang) => {
      try {
        window.localStorage.setItem(STORAGE, l);
      } catch {
        /* ignore */
      }
      setLangState(l);
    },
    t: (key: string) => dict[lang][key] ?? dict.en[key] ?? key,
  }), [lang, dir]);

  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
};

export const useI18n = (): I18nValue => {
  const ctx = useContext(I18nContext);
  if (!ctx) throw new Error('useI18n must be used within LanguageProvider');
  return ctx;
};
