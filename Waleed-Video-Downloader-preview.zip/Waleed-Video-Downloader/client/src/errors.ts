export interface ErrorInfo {
  hintKey: string | null;
  short: string;
  canUpdate: boolean;
}

// Turns a long yt-dlp error dump into a friendly hint + one short line.
export function explainError(raw: string): ErrorInfo {
  const text = String(raw || '');
  const lines = text.split(/\r?\n|\s(?=WARNING:|ERROR:)/).map((l) => l.trim()).filter(Boolean);
  const lastError = [...lines].reverse().find((l) => /^ERROR:/i.test(l));
  const short = (lastError || lines[lines.length - 1] || text).replace(/^ERROR:\s*/i, '').slice(0, 180);

  if (/sign in|not a bot|confirm you.?re not/i.test(text)) {
    return { hintKey: 'hint.signin', short, canUpdate: true };
  }
  if (/precondition check failed|http error 400|unable to extract|nsig|player response/i.test(text)) {
    return { hintKey: 'hint.update', short, canUpdate: true };
  }
  if (/unable to resolve|network is unreachable|timed out|connection (reset|refused)|no address associated/i.test(text)) {
    return { hintKey: 'hint.network', short, canUpdate: false };
  }
  if (/private video|video unavailable|has been removed|not available in your country|members-only/i.test(text)) {
    return { hintKey: 'hint.unavailable', short, canUpdate: false };
  }
  return { hintKey: null, short, canUpdate: false };
}
