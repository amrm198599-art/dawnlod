import React, { useMemo } from 'react';
import createCache from '@emotion/cache';
import { CacheProvider } from '@emotion/react';
import rtlPlugin from 'stylis-plugin-rtl';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import { CssBaseline, Container, Box, Typography, Chip } from '@mui/material';
import DownloadRoundedIcon from '@mui/icons-material/DownloadRounded';
import LinkRoundedIcon from '@mui/icons-material/LinkRounded';
import HighQualityRoundedIcon from '@mui/icons-material/HighQualityRounded';
import Header from './components/Header';
import DownloadForm from './components/DownloadForm';
import DownloadProgress from './components/DownloadProgress';
import DownloadHistory from './components/DownloadHistory';
import { SocketProvider } from './contexts/SocketContext';
import { LanguageProvider, useI18n } from './i18n';
import './App.css';

const buildTheme = (direction: 'rtl' | 'ltr') => createTheme({
  direction,
  palette: {
    mode: 'dark',
    primary: { main: '#16c8f5' },
    secondary: { main: '#8057ff' },
    background: { default: '#030b1b', paper: '#09172d' },
    text: { primary: '#f5f8ff', secondary: '#a5b4d0' },
    success: { main: '#24d6a0' },
  },
  shape: { borderRadius: 18 },
  typography: {
    fontFamily: 'Inter, "Noto Sans Arabic", Tahoma, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif',
    h5: { fontWeight: 750, letterSpacing: '-0.025em' },
    h6: { fontWeight: 700 },
    button: { textTransform: 'none', fontWeight: 700 },
  },
  components: {
    MuiButton: { styleOverrides: { root: { borderRadius: 13, padding: '11px 18px' }, containedPrimary: { color: '#031124', background: 'linear-gradient(110deg, #12c8f5, #6857ff)', boxShadow: '0 8px 24px rgba(36,130,255,.22)' } } },
    MuiCard: { styleOverrides: { root: { background: 'linear-gradient(145deg, rgba(12,29,55,.97), rgba(5,16,35,.98))', border: '1px solid rgba(91,139,207,.19)', boxShadow: '0 18px 50px rgba(0,0,0,.18)', backgroundImage: 'none' } } },
    MuiOutlinedInput: { styleOverrides: { root: { borderRadius: 13, backgroundColor: 'rgba(2,10,25,.55)', '& fieldset': { borderColor: 'rgba(125,158,207,.25)' }, '&:hover fieldset': { borderColor: 'rgba(22,200,245,.65)' } } } },
  },
});

const ltrCache = createCache({ key: 'mui' });
const rtlCache = createCache({ key: 'muirtl', stylisPlugins: [rtlPlugin] });

function Shell() {
  const { t, dir } = useI18n();
  const theme = useMemo(() => buildTheme(dir), [dir]);
  return (
    <CacheProvider value={dir === 'rtl' ? rtlCache : ltrCache}>
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <SocketProvider>
          <div className="App" dir={dir}>
            <Header />
            <Container maxWidth="md" className="main-container">
              <Box className="intro-block">
                <Chip icon={<DownloadRoundedIcon />} label={t('eyebrow')} className="eyebrow-chip" />
                <Typography component="h1" className="hero-title">
                  {t('heroA')} <span>{t('heroB')}</span>
                </Typography>
                <Typography className="hero-subtitle">{t('heroSub')}</Typography>
                <Box className="feature-row">
                  <span><LinkRoundedIcon /> {t('feat1')}</span>
                  <span><HighQualityRoundedIcon /> {t('feat2')}</span>
                  <span><DownloadRoundedIcon /> {t('feat3')}</span>
                </Box>
              </Box>
              <Box className="content-stack">
                <DownloadForm />
                <DownloadProgress />
                <DownloadHistory />
              </Box>
              <Box component="footer" className="app-footer">
                <span className="footer-mark">W</span>
                <span>Waleed Video Downloader</span>
                <span className="footer-dot" />
                <span>{t('footer')}</span>
              </Box>
            </Container>
          </div>
        </SocketProvider>
      </ThemeProvider>
    </CacheProvider>
  );
}

function App() {
  return (
    <LanguageProvider>
      <Shell />
    </LanguageProvider>
  );
}

export default App;
