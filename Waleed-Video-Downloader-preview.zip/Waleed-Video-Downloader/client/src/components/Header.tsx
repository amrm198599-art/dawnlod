import React, { useState, useEffect } from 'react';
import {
  Box, Chip, Alert, IconButton, Tooltip, Dialog, DialogTitle, DialogContent, DialogActions,
  TextField, Button, ToggleButtonGroup, ToggleButton, Typography
} from '@mui/material';
import {
  CheckCircle as CheckCircleIcon,
  Warning as WarningIcon,
  Settings as SettingsIcon,
  Translate as TranslateIcon
} from '@mui/icons-material';
import { api, getServerUrl, getApiKey, saveSettings } from '../api';
import { isNative, YtDlp } from '../engine';
import { useI18n } from '../i18n';

type Status = 'checking' | 'connected' | 'disconnected' | 'unauthorized';

const Header: React.FC = () => {
  const { t, lang, setLang } = useI18n();
  const [backendStatus, setBackendStatus] = useState<Status>('checking');
  const [open, setOpen] = useState(false);
  const [serverUrl, setServerUrl] = useState('');
  const [apiKey, setApiKey] = useState('');
  const [updating, setUpdating] = useState(false);
  const [updateMsg, setUpdateMsg] = useState<{ ok: boolean; text: string } | null>(null);

  useEffect(() => {
    if (isNative) return undefined; // the phone is the engine; no server to check
    const check = async () => {
      try {
        await api.get('/formats/quality-presets');
        setBackendStatus('connected');
      } catch (error: any) {
        setBackendStatus(error?.response?.status === 401 ? 'unauthorized' : 'disconnected');
      }
    };
    check();
    const interval = setInterval(check, 30000);
    return () => clearInterval(interval);
  }, []);

  const openSettings = () => {
    setServerUrl(getServerUrl());
    setApiKey(getApiKey());
    setUpdateMsg(null);
    setOpen(true);
  };

  const save = () => {
    saveSettings(serverUrl, apiKey);
    window.location.reload();
  };

  const updateEngine = async () => {
    setUpdating(true);
    setUpdateMsg(null);
    try {
      await YtDlp.updateEngine({ channel: 'nightly' });
      setUpdateMsg({ ok: true, text: t('settings.updated') });
    } catch (e: any) {
      setUpdateMsg({ ok: false, text: `${t('settings.updateFailed')}${e?.message ? ` (${e.message})` : ''}` });
    } finally {
      setUpdating(false);
    }
  };

  const label =
    backendStatus === 'connected' ? t('header.online')
      : backendStatus === 'disconnected' ? t('header.offline')
        : backendStatus === 'unauthorized' ? t('header.needKey')
          : t('header.checking');

  return (
    <>
      <header className="site-header">
        <div className="header-inner">
          <a className="brand-lockup" href="/" aria-label="Waleed Video Downloader">
            <img className="brand-img" src={`${process.env.PUBLIC_URL}/logo192.png`} alt="" width={44} height={44} />
            <span className="brand-copy"><strong>Waleed</strong><small>VIDEO DOWNLOADER</small></span>
          </a>
          <Box className="header-status">
            {!isNative && (
              <Chip
                className={`backend-chip ${backendStatus === 'connected' ? 'connected' : backendStatus === 'checking' ? 'checking' : 'disconnected'}`}
                label={label}
                size="small"
                icon={backendStatus === 'connected' ? <CheckCircleIcon /> : backendStatus === 'checking' ? undefined : <WarningIcon />}
              />
            )}
            <Tooltip title={t('settings.language')}>
              <IconButton onClick={() => setLang(lang === 'ar' ? 'en' : 'ar')} aria-label={t('settings.language')} size="small">
                <TranslateIcon />
                <Typography component="span" sx={{ fontSize: 12, fontWeight: 700, mx: 0.5 }}>
                  {lang === 'ar' ? 'EN' : 'ع'}
                </Typography>
              </IconButton>
            </Tooltip>
            <Tooltip title={t('settings.title')}>
              <IconButton onClick={openSettings} aria-label={t('settings.title')} size="small">
                <SettingsIcon />
              </IconButton>
            </Tooltip>
          </Box>
        </div>
      </header>

      {!isNative && backendStatus === 'disconnected' && (
        <Alert severity="warning" className="backend-alert">{t('header.offlineAlert')}</Alert>
      )}
      {!isNative && backendStatus === 'unauthorized' && (
        <Alert severity="warning" className="backend-alert">{t('header.keyAlert')}</Alert>
      )}

      <Dialog open={open} onClose={() => setOpen(false)} fullWidth maxWidth="xs">
        <DialogTitle>{t('settings.title')}</DialogTitle>
        <DialogContent>
          <Typography variant="body2" color="text.secondary" sx={{ mt: 1, mb: 1 }}>
            {t('settings.language')}
          </Typography>
          <ToggleButtonGroup
            exclusive
            size="small"
            value={lang}
            onChange={(_e, v) => { if (v) setLang(v); }}
          >
            <ToggleButton value="ar">العربية</ToggleButton>
            <ToggleButton value="en">English</ToggleButton>
          </ToggleButtonGroup>

          {isNative ? (
            <Box sx={{ mt: 3 }}>
              <Button variant="contained" fullWidth onClick={updateEngine} disabled={updating}>
                {updating ? t('settings.updating') : t('settings.update')}
              </Button>
              <Typography variant="caption" color="text.secondary" component="div" sx={{ mt: 1 }}>
                {t('settings.engineHint')}
              </Typography>
              {updateMsg && (
                <Alert severity={updateMsg.ok ? 'success' : 'error'} sx={{ mt: 2 }}>{updateMsg.text}</Alert>
              )}
            </Box>
          ) : (
            <>
              <TextField
                fullWidth margin="normal" label={t('settings.server')}
                placeholder="https://your-server.example"
                value={serverUrl} onChange={(e) => setServerUrl(e.target.value)}
                inputProps={{ dir: 'ltr' }}
              />
              <TextField
                fullWidth margin="normal" label={t('settings.apiKey')} type="password"
                value={apiKey} onChange={(e) => setApiKey(e.target.value)}
                helperText={t('settings.keyHelp')}
                inputProps={{ dir: 'ltr' }}
              />
            </>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpen(false)}>{isNative ? t('settings.close') : t('settings.cancel')}</Button>
          {!isNative && <Button variant="contained" onClick={save}>{t('settings.save')}</Button>}
        </DialogActions>
      </Dialog>
    </>
  );
};

export default Header;
