import React, { useState, useEffect, useCallback } from 'react';
import {
  Card, CardContent, Typography, List, ListItem, ListItemText, ListItemSecondaryAction,
  IconButton, Chip, Box, Alert, Tooltip, Dialog, DialogTitle, DialogContent, DialogActions, Button
} from '@mui/material';
import {
  Delete as DeleteIcon,
  Refresh as RefreshIcon,
  SaveAlt as SaveAltIcon,
  OpenInNew as OpenInNewIcon,
  PlayCircleOutline as PlayCircleOutlineIcon,
  Close as CloseIcon
} from '@mui/icons-material';
import { api, errMsg, getApiUrl } from '../api';
import { isNative, YtDlp, loadHistory, removeHistory } from '../engine';
import { useI18n } from '../i18n';
import { useSocket } from '../contexts/SocketContext';

interface DownloadedFile {
  key: string; // server: file name, native: history id
  name: string;
  size: number;
  date: string;
  uri?: string;
  mime?: string;
}

const DownloadHistory: React.FC = () => {
  const { t, lang } = useI18n();
  const { downloads } = useSocket();
  const [files, setFiles] = useState<DownloadedFile[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [previewFile, setPreviewFile] = useState<DownloadedFile | null>(null);
  const [previewUrl, setPreviewUrl] = useState('');
  const [previewError, setPreviewError] = useState(false);
  const [previewLoading, setPreviewLoading] = useState(false);

  const fetchFiles = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      if (isNative) {
        setFiles(loadHistory().map((h) => ({ key: h.id, name: h.name, size: h.size, date: h.date, uri: h.uri, mime: h.mime })));
      } else {
        const response = await api.get('/download/list');
        setFiles(response.data.map((f: any) => ({ key: f.name, name: f.name, size: f.size, date: f.createdAt })));
      }
    } catch (e: any) {
      setFiles([]);
      setError(errMsg(e, 'err.load', t));
    } finally {
      setLoading(false);
    }
  }, [t]);

  useEffect(() => {
    fetchFiles();
  }, [fetchFiles]);

  // Refresh the list whenever a download finishes.
  const completedCount = downloads.filter((d) => d.status === 'completed').length;
  useEffect(() => {
    if (completedCount > 0) fetchFiles();
  }, [completedCount, fetchFiles]);

  const deleteFile = async (file: DownloadedFile) => {
    try {
      if (isNative) {
        if (file.uri) await YtDlp.deleteFile({ uri: file.uri });
        removeHistory(file.key);
      } else {
        await api.delete(`/download/${encodeURIComponent(file.name)}`);
      }
      setFiles((prev) => prev.filter((f) => f.key !== file.key));
    } catch (e: any) {
      setError(errMsg(e, 'err.delete', t));
    }
  };

  // Native: open the file with a player app. Web: get a short-lived link and let the browser download it.
  const saveOrOpen = async (file: DownloadedFile) => {
    try {
      if (isNative) {
        await YtDlp.openFile({ uri: file.uri || '', mime: file.mime || '*/*' });
      } else {
        const { data } = await api.post(`/files/${encodeURIComponent(file.name)}/token`);
        window.location.assign(`${getApiUrl()}/files/${encodeURIComponent(file.name)}?token=${data.token}`);
      }
    } catch (e: any) {
      setError(isNative ? t('err.open') : errMsg(e, 'err.save', t));
    }
  };

  const closePreview = () => {
    setPreviewFile(null);
    setPreviewUrl('');
    setPreviewError(false);
    setPreviewLoading(false);
  };

  const previewVideo = async (file: DownloadedFile) => {
    setPreviewFile(file);
    setPreviewUrl('');
    setPreviewError(false);
    setPreviewLoading(true);
    try {
      if (isNative) {
        // MediaStore content:// URIs are used by native Android downloads.
        setPreviewUrl(file.uri || '');
      } else {
        const { data } = await api.post(`/files/${encodeURIComponent(file.name)}/token`);
        setPreviewUrl(`${getApiUrl()}/files/${encodeURIComponent(file.name)}?token=${data.token}`);
      }
    } catch (e: any) {
      setPreviewError(true);
      setError(errMsg(e, 'err.open', t));
    } finally {
      setPreviewLoading(false);
    }
  };

  const formatFileSize = (bytes: number) => {
    if (!bytes) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.min(sizes.length - 1, Math.floor(Math.log(bytes) / Math.log(k)));
    return `${parseFloat((bytes / Math.pow(k, i)).toFixed(2))} ${sizes[i]}`;
  };

  const getFileType = (filename: string): 'video' | 'audio' | 'unknown' => {
    const ext = filename.split('.').pop()?.toLowerCase() || '';
    if (['mp4', 'avi', 'mkv', 'mov', 'wmv', 'flv', 'webm'].includes(ext)) return 'video';
    if (['mp3', 'm4a', 'wav', 'flac', 'ogg', 'opus', 'aac'].includes(ext)) return 'audio';
    return 'unknown';
  };

  const typeColor = (type: string) => (type === 'video' ? 'primary' : type === 'audio' ? 'secondary' : 'default');

  return (
    <Card>
      <CardContent>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
          <Typography variant="h5">{t('history.title')}</Typography>
          <Tooltip title={t('history.refresh')}>
            <IconButton onClick={fetchFiles} disabled={loading} aria-label={t('history.refresh')}>
              <RefreshIcon />
            </IconButton>
          </Tooltip>
        </Box>

        {isNative && (
          <Typography variant="caption" color="text.secondary" component="div" sx={{ mb: 1 }}>
            {t('history.savedIn')}
          </Typography>
        )}

        {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

        {files.length === 0 ? (
          <Typography variant="body2" color="text.secondary" sx={{ textAlign: 'center', py: 4 }}>
            {t('history.empty')}
          </Typography>
        ) : (
          <List>
            {files.map((file, index) => {
              const type = getFileType(file.name);
              return (
                <ListItem key={file.key} divider={index < files.length - 1} sx={{ pr: 12, pl: 2 }}>
                  <ListItemText
                    primary={
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, flexWrap: 'wrap' }}>
                        <Typography variant="body1" component="span" sx={{ wordBreak: 'break-word' }}>
                          {file.name}
                        </Typography>
                        <Chip label={t(`type.${type}`)} size="small" color={typeColor(type) as any} />
                      </Box>
                    }
                    secondary={
                      <Box>
                        <Typography variant="caption" component="div">
                          {t('history.size')}: {formatFileSize(file.size)}
                        </Typography>
                        <Typography variant="caption" component="div">
                          {t('history.downloaded')}: {new Date(file.date).toLocaleString(lang === 'ar' ? 'ar-EG' : undefined)}
                        </Typography>
                      </Box>
                    }
                  />
                  <ListItemSecondaryAction>
                    {type === 'video' && (
                      <Tooltip title={lang === 'ar' ? 'معاينة الفيديو' : 'Preview video'}>
                        <IconButton edge="end" onClick={() => previewVideo(file)} color="primary" sx={{ mx: 0.5 }} aria-label={lang === 'ar' ? 'معاينة الفيديو' : 'Preview video'}>
                          <PlayCircleOutlineIcon />
                        </IconButton>
                      </Tooltip>
                    )}
                    <Tooltip title={isNative ? t('history.open') : t('history.save')}>
                      <IconButton edge="end" onClick={() => saveOrOpen(file)} color="primary" sx={{ mx: 0.5 }}>
                        {isNative ? <OpenInNewIcon /> : <SaveAltIcon />}
                      </IconButton>
                    </Tooltip>
                    <Tooltip title={t('history.delete')}>
                      <IconButton edge="end" onClick={() => deleteFile(file)} color="error">
                        <DeleteIcon />
                      </IconButton>
                    </Tooltip>
                  </ListItemSecondaryAction>
                </ListItem>
              );
            })}
          </List>
        )}
      </CardContent>
      <Dialog open={Boolean(previewFile)} onClose={closePreview} fullWidth maxWidth="md" PaperProps={{ sx: { bgcolor: '#071329', backgroundImage: 'none', border: '1px solid rgba(91,139,207,.25)' } }}>
        <DialogTitle sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 2 }}>
          <Box sx={{ minWidth: 0, overflowWrap: 'anywhere' }}>{previewFile?.name || (lang === 'ar' ? 'معاينة الفيديو' : 'Video preview')}</Box>
          <IconButton onClick={closePreview} aria-label={lang === 'ar' ? 'إغلاق' : 'Close'}><CloseIcon /></IconButton>
        </DialogTitle>
        <DialogContent>
          {previewLoading ? (
            <Typography color="text.secondary">{lang === 'ar' ? 'جارٍ تجهيز المعاينة…' : 'Preparing preview…'}</Typography>
          ) : previewUrl && !previewError ? (
            <Box sx={{ width: '100%', bgcolor: '#000', borderRadius: 2, overflow: 'hidden', minHeight: 180 }}>
              <video
                key={previewUrl}
                src={previewUrl}
                controls
                playsInline
                preload="metadata"
                onError={() => setPreviewError(true)}
                style={{ display: 'block', width: '100%', maxHeight: '65vh', minHeight: 180, background: '#000' }}
              />
            </Box>
          ) : (
            <Alert severity="warning">
              {lang === 'ar'
                ? 'تعذّرت المعاينة داخل التطبيق لهذا الملف. يمكنك فتحه باستخدام مشغّل الفيديو على الهاتف.'
                : 'This file could not be previewed in the app. You can open it with your phone’s video player.'}
            </Alert>
          )}
          {previewError && previewFile && isNative && (
            <Button sx={{ mt: 2 }} variant="contained" onClick={() => saveOrOpen(previewFile)}>
              {lang === 'ar' ? 'فتح بمشغّل الهاتف' : 'Open in phone player'}
            </Button>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={closePreview}>{lang === 'ar' ? 'إغلاق' : 'Close'}</Button>
        </DialogActions>
      </Dialog>
    </Card>
  );
};

export default DownloadHistory;
