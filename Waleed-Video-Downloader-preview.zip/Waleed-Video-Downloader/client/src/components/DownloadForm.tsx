import React, { useState } from 'react';
import {
  Card, CardContent, TextField, Button, FormControl, InputLabel, Select, MenuItem,
  FormControlLabel, Switch, Box, Typography, Chip, Alert, Collapse, IconButton, Tooltip
} from '@mui/material';
import {
  Download as DownloadIcon,
  Info as InfoIcon,
  ExpandMore as ExpandMoreIcon,
  ExpandLess as ExpandLessIcon
} from '@mui/icons-material';
import { api, errMsg } from '../api';
import { isNative, YtDlp, QUALITY_VALUES, AUDIO_VALUES } from '../engine';
import { useI18n } from '../i18n';
import { useSocket } from '../contexts/SocketContext';

interface VideoInfo {
  title: string;
  uploader?: string;
  duration?: number;
  view_count?: number;
  thumbnail?: string;
  extractor?: string;
}

const newId = () => `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

const DownloadForm: React.FC = () => {
  const { t } = useI18n();
  const { addDownload } = useSocket();
  const [url, setUrl] = useState('');
  const [audioOnly, setAudioOnly] = useState(false);
  const [format, setFormat] = useState('mp3');
  const [quality, setQuality] = useState('best');
  const [videoInfo, setVideoInfo] = useState<VideoInfo | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [showAdvanced, setShowAdvanced] = useState(false);

  const fetchVideoInfo = async () => {
    if (!url.trim()) {
      setError(t('form.enterUrl'));
      return;
    }
    setLoading(true);
    setError('');
    setSuccess('');
    setVideoInfo(null);
    try {
      if (isNative) {
        setVideoInfo(await YtDlp.getInfo({ url: url.trim() }));
      } else {
        const response = await api.get('/info', { params: { url: url.trim() } });
        setVideoInfo(response.data);
      }
    } catch (e: any) {
      setError(errMsg(e, 'err.info', t));
    } finally {
      setLoading(false);
    }
  };

  const handleDownload = async () => {
    if (!url.trim()) {
      setError(t('form.enterUrl'));
      return;
    }
    setLoading(true);
    setError('');
    setSuccess('');
    try {
      if (isNative) {
        const id = newId();
        addDownload({ id, url: url.trim(), status: 'starting', progress: 0, filename: '', error: null });
        await YtDlp.download({
          downloadId: id,
          url: url.trim(),
          audioOnly,
          format: audioOnly ? format : undefined,
          quality: !audioOnly ? quality : undefined
        });
      } else {
        await api.post('/download', {
          url: url.trim(),
          format: audioOnly ? format : undefined,
          quality: !audioOnly ? quality : undefined,
          audioOnly
        });
      }
      setSuccess(t('form.started'));
      setUrl('');
      setVideoInfo(null);
    } catch (e: any) {
      setError(errMsg(e, 'err.download', t));
    } finally {
      setLoading(false);
    }
  };

  const formatDuration = (seconds: number) => {
    const s = Math.floor(seconds);
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const sec = s % 60;
    return h > 0
      ? `${h}:${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')}`
      : `${m}:${String(sec).padStart(2, '0')}`;
  };

  return (
    <Card sx={{ mb: 3 }}>
      <CardContent>
        <Typography variant="h5" gutterBottom>{t('form.title')}</Typography>

        <Box sx={{ mb: 3 }}>
          <TextField
            fullWidth
            label={t('form.urlLabel')}
            placeholder={t('form.urlPlaceholder')}
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            margin="normal"
            inputProps={{ dir: 'ltr', inputMode: 'url', autoCapitalize: 'none', autoCorrect: 'off' }}
          />

          <Box sx={{ mt: 2, display: 'flex', gap: 2, alignItems: 'center', flexWrap: 'wrap' }}>
            <Button variant="outlined" startIcon={<InfoIcon />} onClick={fetchVideoInfo} disabled={loading || !url.trim()}>
              {t('form.getInfo')}
            </Button>
            <Button variant="contained" startIcon={<DownloadIcon />} onClick={handleDownload} disabled={loading || !url.trim()}>
              {t('form.download')}
            </Button>
            <Tooltip title={t('form.advanced')}>
              <IconButton onClick={() => setShowAdvanced(!showAdvanced)} aria-label={t('form.advanced')}>
                {showAdvanced ? <ExpandLessIcon /> : <ExpandMoreIcon />}
              </IconButton>
            </Tooltip>
          </Box>
        </Box>

        <Collapse in={showAdvanced}>
          <Box sx={{ mb: 3, p: 2, bgcolor: 'rgba(255,255,255,0.04)', borderRadius: 1 }}>
            <Typography variant="h6" gutterBottom>{t('form.options')}</Typography>

            <FormControlLabel
              control={<Switch checked={audioOnly} onChange={(e) => setAudioOnly(e.target.checked)} />}
              label={t('form.audioOnly')}
            />

            {audioOnly ? (
              <FormControl fullWidth margin="normal">
                <InputLabel>{t('form.audioFormat')}</InputLabel>
                <Select value={format} label={t('form.audioFormat')} onChange={(e) => setFormat(e.target.value)}>
                  {AUDIO_VALUES.map((v) => (
                    <MenuItem key={v} value={v}>{t(`af.${v}`)}</MenuItem>
                  ))}
                </Select>
              </FormControl>
            ) : (
              <FormControl fullWidth margin="normal">
                <InputLabel>{t('form.videoQuality')}</InputLabel>
                <Select value={quality} label={t('form.videoQuality')} onChange={(e) => setQuality(e.target.value)}>
                  {QUALITY_VALUES.map((v) => (
                    <MenuItem key={v} value={v}>{t(`vq.${v}`)}</MenuItem>
                  ))}
                </Select>
              </FormControl>
            )}
          </Box>
        </Collapse>

        {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
        {success && <Alert severity="success" sx={{ mb: 2 }}>{success}</Alert>}

        {videoInfo && (
          <Card variant="outlined" sx={{ mt: 2 }}>
            <CardContent>
              <Typography variant="h6" gutterBottom>{t('form.info')}</Typography>
              <Box sx={{ display: 'flex', gap: 2, mb: 2 }}>
                {videoInfo.thumbnail && (
                  <img
                    src={videoInfo.thumbnail}
                    alt=""
                    style={{ width: 120, height: 90, objectFit: 'cover', borderRadius: 4 }}
                  />
                )}
                <Box sx={{ flexGrow: 1, minWidth: 0 }}>
                  <Typography variant="subtitle1" fontWeight="bold">{videoInfo.title}</Typography>
                  {videoInfo.uploader && (
                    <Typography variant="body2" color="text.secondary" gutterBottom>
                      {t('form.by')} {videoInfo.uploader}
                    </Typography>
                  )}
                  <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap', mt: 1 }}>
                    {typeof videoInfo.duration === 'number' && videoInfo.duration > 0 && (
                      <Chip size="small" label={`${t('form.duration')}: ${formatDuration(videoInfo.duration)}`} />
                    )}
                    {typeof videoInfo.view_count === 'number' && (
                      <Chip size="small" label={`${t('form.views')}: ${videoInfo.view_count.toLocaleString()}`} />
                    )}
                    {videoInfo.extractor && <Chip size="small" label={videoInfo.extractor} />}
                  </Box>
                </Box>
              </Box>
            </CardContent>
          </Card>
        )}
      </CardContent>
    </Card>
  );
};

export default DownloadForm;
