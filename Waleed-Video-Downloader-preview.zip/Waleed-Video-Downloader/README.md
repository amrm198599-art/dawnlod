# Waleed Video Downloader / تحميل فيديو وليد

Free video & audio downloader (Arabic + English, RTL). Like Seal / SnapTube:
**the Android app downloads directly on the phone** using yt-dlp + FFmpeg. No server, no hosting cost.

## Features
- 1000+ sites (YouTube, TikTok, Facebook, Instagram, X, Vimeo …) via yt-dlp
- Video 144p → 4K (MP4) or audio (MP3, M4A, WAV, FLAC, OGG, original)
- Arabic / English UI with full RTL, switchable in-app
- Progress, history, open file, delete; saved to `Downloads/WaleedDownloader`
- **Update engine** button (Settings ⚙) when a site changes and downloads stop working
- Optional web mode + Node server (`server/`) if you prefer hosting it (API key, rate limits, tests)

## Build the Android app (GitHub Actions)
Full guide: [ANDROID-BUILD-AR.md](ANDROID-BUILD-AR.md). Short version:
1. Upload the **contents** of this folder to the root of your GitHub repo.
2. Actions → **Build Waleed Video Downloader Android** → Run workflow.
3. Download the artifact: `app-debug.apk` (testing) or signed `app-release.apk` / `.aab` (after adding the keystore secrets from `./scripts/generate-keystore.sh`).

How it works: CI builds the React UI, runs `npx cap add android`, then `scripts/configure-android.js` adds Kotlin,
the native `YtDlpPlugin` (wraps [youtubedl-android](https://github.com/yausername/youtubedl-android)), minSdk 24, ABI settings and signing.

Notes
- APK is large (~80 MB) because Python + FFmpeg are bundled (same as Seal).
- Full "Downloads folder" saving needs Android 10+. Keep the app open while a download runs.
- Min Android: 7.0 (API 24).

## Local web/server mode (optional)
```bash
npm run install:all && npm run dev   # needs node 18+, yt-dlp, ffmpeg
npm test                             # server unit tests
```
Server deployment: `Dockerfile`, `.env.example`. In production the server refuses to start without `API_KEY`.

## License
See [NOTICE.md](NOTICE.md). The Android build bundles GPL-3.0 components, so distributed APKs must ship with their
source under GPL-3.0. Download only content you own or are allowed to save. Google Play does not accept YouTube
downloaders; distribute the APK directly.
