#!/usr/bin/env node
// Run after `npx cap add android`. Wires release signing + versioning into the generated Gradle project
// and tunes gradle.properties for CI. Safe to run more than once.
const fs = require('fs');
const path = require('path');

const androidDir = path.resolve(process.env.ANDROID_DIR || 'android');
const appGradle = path.join(androidDir, 'app', 'build.gradle');
const gradleProps = path.join(androidDir, 'gradle.properties');
const template = path.join(__dirname, 'android', 'signing.gradle');

if (!fs.existsSync(appGradle)) {
  console.error(`Not found: ${appGradle}. Run "npx cap add android" first.`);
  process.exit(1);
}

fs.copyFileSync(template, path.join(androidDir, 'app', 'signing.gradle'));
let gradle = fs.readFileSync(appGradle, 'utf8');
if (!gradle.includes("apply from: 'signing.gradle'")) {
  gradle = `${gradle.trimEnd()}\n\napply from: 'signing.gradle'\n`;
  fs.writeFileSync(appGradle, gradle);
}

let props = fs.existsSync(gradleProps) ? fs.readFileSync(gradleProps, 'utf8') : '';
const wanted = {
  'org.gradle.jvmargs': '-Xmx3072m -Dfile.encoding=UTF-8',
  'org.gradle.caching': 'true',
  'org.gradle.parallel': 'true'
};
for (const [k, v] of Object.entries(wanted)) {
  props = props.split('\n').filter((l) => !l.startsWith(`${k}=`)).join('\n');
  props = `${props.trimEnd()}\n${k}=${v}\n`;
}
fs.writeFileSync(gradleProps, props);

console.log(process.env.KEYSTORE_PATH
  ? `Release signing enabled (keystore: ${process.env.KEYSTORE_PATH}).`
  : 'No KEYSTORE_PATH: release output will be unsigned; use the debug APK for testing.');
