import React, { useState, useEffect } from 'react';
import {
  Box, Chip, Alert, IconButton, Tooltip, Dialog, DialogTitle, DialogContent, DialogActions, TextField, Button
} from '@mui/material';
import {
  CheckCircle as CheckCircleIcon,
  Warning as WarningIcon,
  Settings as SettingsIcon
} from '@mui/icons-material';
import { api, getServerUrl, getApiKey, saveSettings } from '../api';

type Status = 'checking' | 'connected' | 'disconnected' | 'unauthorized';

const Header: React.FC = () => {
  const [backendStatus, setBackendStatus] = useState<Status>('checking');
  const [open, setOpen] = useState(false);
  const [serverUrl, setServerUrl] = useState('');
  const [apiKey, setApiKey] = useState('');

  useEffect(() => {
    const checkBackend = async () => {
      try {
        await api.get('/formats/quality-presets');
        setBackendStatus('connected');
      } catch (error: any) {
        setBackendStatus(error?.response?.status === 401 ? 'unauthorized' : 'disconnected');
      }
    };
    checkBackend();
    const interval = setInterval(checkBackend, 30000);
    return () => clearInterval(interval);
  }, []);

  const openSettings = () => {
    setServerUrl(getServerUrl());
    setApiKey(getApiKey());
    setOpen(true);
  };

  const save = () => {
    saveSettings(serverUrl, apiKey);
    // Reconnect the socket and refresh all data with the new settings.
    window.location.reload();
  };

  const label =
    backendStatus === 'connected' ? 'Server online'
      : backendStatus === 'disconnected' ? 'Server offline'
        : backendStatus === 'unauthorized' ? 'API key needed'
          : 'Checking server';

  return (
    <>
      <header className="site-header">
        <div className="header-inner">
          <a className="brand-lockup" href="/" aria-label="Waleed Video Downloader home">
            <span className="brand-icon"><span className="brand-w">W</span><span className="brand-play">▶</span><span className="brand-film">▥</span></span>
            <span className="brand-copy"><strong>Waleed</strong><small>VIDEO DOWNLOADER</small></span>
          </a>
          <Box className="header-status">
            <Chip
              className={`backend-chip ${backendStatus === 'connected' ? 'connected' : backendStatus === 'checking' ? 'checking' : 'disconnected'}`}
              label={label}
              size="small"
              icon={backendStatus === 'connected' ? <CheckCircleIcon /> : backendStatus === 'checking' ? undefined : <WarningIcon />}
            />
            <Tooltip title="Settings">
              <IconButton onClick={openSettings} aria-label="Settings" size="small">
                <SettingsIcon />
              </IconButton>
            </Tooltip>
          </Box>
        </div>
      </header>

      {backendStatus === 'disconnected' && (
        <Alert severity="warning" className="backend-alert">
          <strong>Download server is unreachable.</strong> Check the server address in Settings (⚙) and that the server is running.
        </Alert>
      )}
      {backendStatus === 'unauthorized' && (
        <Alert severity="warning" className="backend-alert">
          <strong>The server needs an API key.</strong> Open Settings (⚙) and enter it.
        </Alert>
      )}

      <Dialog open={open} onClose={() => setOpen(false)} fullWidth maxWidth="xs">
        <DialogTitle>Settings</DialogTitle>
        <DialogContent>
          <TextField
            fullWidth margin="normal" label="Server address"
            placeholder="https://your-server.example"
            value={serverUrl} onChange={(e) => setServerUrl(e.target.value)}
          />
          <TextField
            fullWidth margin="normal" label="API key" type="password"
            value={apiKey} onChange={(e) => setApiKey(e.target.value)}
            helperText="Stored only on this device."
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpen(false)}>Cancel</Button>
          <Button variant="contained" onClick={save}>Save</Button>
        </DialogActions>
      </Dialog>
    </>
  );
};

export default Header;
