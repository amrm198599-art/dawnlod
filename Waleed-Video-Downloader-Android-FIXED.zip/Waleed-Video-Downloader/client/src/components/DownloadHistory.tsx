import React, { useState, useEffect, useCallback } from 'react';
import {
  Card,
  CardContent,
  Typography,
  List,
  ListItem,
  ListItemText,
  ListItemSecondaryAction,
  IconButton,
  Chip,
  Box,
  Alert,
  Tooltip
} from '@mui/material';
import {
  Delete as DeleteIcon,
  SaveAlt as SaveAltIcon,
  Refresh as RefreshIcon
} from '@mui/icons-material';
import { api, errMsg, getApiUrl } from '../api';
import { useSocket } from '../contexts/SocketContext';

interface DownloadedFile {
  name: string;
  size: number;
  createdAt: string;
  modifiedAt: string;
}

const DownloadHistory: React.FC = () => {
  const [files, setFiles] = useState<DownloadedFile[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const { downloads } = useSocket();

  const fetchFiles = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const response = await api.get('/download/list');
      setFiles(response.data);
    } catch (e: any) {
      setFiles([]);
      setError(errMsg(e, 'Failed to load downloaded files'));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchFiles();
  }, [fetchFiles]);

  // Refresh the list whenever a download finishes.
  const completedCount = downloads.filter((d) => d.status === 'completed').length;
  useEffect(() => {
    if (completedCount > 0) fetchFiles();
  }, [completedCount, fetchFiles]);

  const deleteFile = async (filename: string) => {
    try {
      await api.delete(`/download/${encodeURIComponent(filename)}`);
      setFiles((prev) => prev.filter((file) => file.name !== filename));
    } catch (e: any) {
      setError(errMsg(e, 'Failed to delete file'));
    }
  };

  // Gets a short-lived link and lets the browser / Android system download the file to the device.
  const saveFile = async (filename: string) => {
    try {
      const { data } = await api.post(`/files/${encodeURIComponent(filename)}/token`);
      window.location.assign(`${getApiUrl()}/files/${encodeURIComponent(filename)}?token=${data.token}`);
    } catch (e: any) {
      setError(errMsg(e, 'Failed to prepare the download'));
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString();
  };

  const getFileType = (filename: string) => {
    const extension = filename.split('.').pop()?.toLowerCase();
    
    if (['mp4', 'avi', 'mkv', 'mov', 'wmv', 'flv', 'webm'].includes(extension || '')) {
      return 'video';
    }
    if (['mp3', 'm4a', 'wav', 'flac', 'ogg', 'aac'].includes(extension || '')) {
      return 'audio';
    }
    return 'unknown';
  };

  const getFileTypeColor = (type: string) => {
    switch (type) {
      case 'video':
        return 'primary';
      case 'audio':
        return 'secondary';
      default:
        return 'default';
    }
  };

  return (
    <Card>
      <CardContent>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
          <Typography variant="h5">
            Download History
          </Typography>
          <Tooltip title="Refresh">
            <IconButton onClick={fetchFiles} disabled={loading}>
              <RefreshIcon />
            </IconButton>
          </Tooltip>
        </Box>

        {error && (
          <Alert severity="error" sx={{ mb: 2 }}>
            {error}
          </Alert>
        )}

        {files.length === 0 ? (
          <Typography variant="body2" color="text.secondary" sx={{ textAlign: 'center', py: 4 }}>
            No downloaded files yet
          </Typography>
        ) : (
          <List>
            {files.map((file, index) => (
              <ListItem key={file.name} divider={index < files.length - 1} sx={{ pr: 12 }}>
                <ListItemText
                  primary={
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <Typography variant="body1" component="span">
                        {file.name}
                      </Typography>
                      <Chip 
                        label={getFileType(file.name)} 
                        size="small" 
                        color={getFileTypeColor(getFileType(file.name)) as any}
                      />
                    </Box>
                  }
                  secondary={
                    <Box>
                      <Typography variant="caption" component="div">
                        Size: {formatFileSize(file.size)}
                      </Typography>
                      <Typography variant="caption" component="div">
                        Downloaded: {formatDate(file.createdAt)}
                      </Typography>
                    </Box>
                  }
                />
                <ListItemSecondaryAction>
                  <Tooltip title="Save to device">
                    <IconButton edge="end" onClick={() => saveFile(file.name)} color="primary" sx={{ mr: 0.5 }}>
                      <SaveAltIcon />
                    </IconButton>
                  </Tooltip>
                  <Tooltip title="Delete">
                    <IconButton 
                      edge="end" 
                      onClick={() => deleteFile(file.name)}
                      color="error"
                    >
                      <DeleteIcon />
                    </IconButton>
                  </Tooltip>
                </ListItemSecondaryAction>
              </ListItem>
            ))}
          </List>
        )}
      </CardContent>
    </Card>
  );
};

export default DownloadHistory;
