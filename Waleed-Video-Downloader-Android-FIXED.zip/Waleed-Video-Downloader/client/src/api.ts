import axios from 'axios';

const KEY_STORAGE = 'wvd_api_key';
const URL_STORAGE = 'wvd_server_url';

const safeGet = (k: string): string => {
  try {
    return window.localStorage.getItem(k) || '';
  } catch {
    return '';
  }
};

const safeSet = (k: string, v: string) => {
  try {
    if (v) window.localStorage.setItem(k, v);
    else window.localStorage.removeItem(k);
  } catch {
    /* storage unavailable */
  }
};

const clean = (u: string) => u.trim().replace(/\/api\/?$/, '').replace(/\/+$/, '');

export function getServerUrl(): string {
  const override = clean(safeGet(URL_STORAGE));
  if (override) return override;
  const env = (process.env.REACT_APP_API_URL || '').trim();
  if (env) return clean(env);
  return process.env.NODE_ENV === 'production' ? window.location.origin : 'http://localhost:5000';
}

export const getApiUrl = () => `${getServerUrl()}/api`;
export const getApiKey = () => safeGet(KEY_STORAGE).trim();

export function saveSettings(serverUrl: string, apiKey: string) {
  safeSet(URL_STORAGE, clean(serverUrl));
  safeSet(KEY_STORAGE, apiKey.trim());
}

export const api = axios.create({ timeout: 90000 });
api.interceptors.request.use((config) => {
  config.baseURL = getApiUrl();
  const key = getApiKey();
  if (key) config.headers.set('x-api-key', key);
  return config;
});

export function errMsg(error: any, fallback: string): string {
  if (error?.response?.status === 401) return 'Unauthorized. Enter the correct API key in Settings (⚙).';
  if (error?.response?.status === 429) return error.response.data?.error || 'Too many requests. Try again shortly.';
  if (error?.code === 'ERR_NETWORK' || String(error?.message).includes('Network Error')) {
    return 'Cannot reach the server. Check the server address in Settings (⚙).';
  }
  const data = error?.response?.data;
  return (data?.details ? `${data.error}: ${data.details}` : data?.error) || fallback;
}
