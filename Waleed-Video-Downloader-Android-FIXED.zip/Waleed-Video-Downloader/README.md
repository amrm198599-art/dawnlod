# Waleed Video Downloader

A web + Android video/audio downloader. The app (React, wrapped with Capacitor for Android) talks to a small
Node.js server that runs [yt-dlp](https://github.com/yt-dlp/yt-dlp). Inspired by [Seal](https://github.com/JunkFood02/Seal).

> **How it works:** downloads happen on **your server**, then you tap **Save** to copy the file to your phone.
> The Android app cannot download anything without a deployed server.

## Features
- 1000+ sites via yt-dlp; video quality 144p → 4K; audio (MP3, M4A, WAV, FLAC, OGG, best)
- Live progress over Socket.IO, download history, **Save to device**, delete
- API-key protection, per-IP rate limiting, concurrent-download cap, private-network URL blocking
- Auto-cleanup of old files on the server (`RETENTION_HOURS`)
- In-app Settings (⚙) for server address + API key, so one APK works with any server

## Quick start (local)
Requires Node 18+, `yt-dlp`, and `ffmpeg` (for audio extraction / merging).
```bash
npm run install:all
npm run dev          # API :5000, web UI :3000
npm test             # server unit tests
```

## Deploy the server
```bash
docker build -t waleed-vd .
docker run -d -p 5000:5000 -e API_KEY=$(openssl rand -hex 32) -v wvd-data:/app/downloads waleed-vd
```
Put it behind HTTPS (Caddy / Nginx / your host's TLS) and set `TRUST_PROXY=true`.
See `.env.example` for all options. In production the server **refuses to start without `API_KEY`**.

Keep yt-dlp fresh — sites change often. Rebuild the image regularly or run `yt-dlp -U`.

## Build the Android app
See [ANDROID-BUILD-AR.md](ANDROID-BUILD-AR.md) (Arabic) for the full walkthrough. Short version:
1. Set repo **variable** `API_BASE_URL` = `https://your-server.example`
2. Run `./scripts/generate-keystore.sh` and add the 4 printed values as repo **secrets**
3. GitHub → Actions → *Build Waleed Video Downloader Android* → Run workflow
4. Download the artifact: signed `app-release.apk` and `app-release.aab`

Without the keystore secrets the workflow still builds a **debug APK** for testing.

## API
All `/api/*` routes need header `x-api-key` (except `health` and token-protected file download).

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/health` | Liveness + whether auth is on |
| POST | `/api/download` | Start download `{url, audioOnly, format, quality}` |
| GET | `/api/download/list` | List finished files |
| DELETE | `/api/download/:filename` | Delete a file |
| POST | `/api/files/:filename/token` | Get a 2-minute download token |
| GET | `/api/files/:filename?token=…` | Download the file |
| GET | `/api/info?url=` | Video metadata |
| GET | `/api/info/playlist?url=` | Playlist entries (max 200) |
| GET | `/api/formats?url=` | Available formats |
| GET | `/api/formats/quality-presets` | Quality/format presets |

Socket.IO (auth: `{ key }`): `download-start`, `download-progress`, `download-complete`, `download-error`.

## Security notes
- Private/localhost URLs are blocked. This is a hostname check, not full DNS-rebinding protection; keep the
  server on a network that cannot reach sensitive internal services.
- Never commit `*.keystore` / `*.jks` (already in `.gitignore`).
- Download only content you own or are allowed to save, and follow each site's terms. Apps that download from
  YouTube are not accepted on Google Play; distribute the APK directly.

## License
WTFPL — see [LICENSE](LICENSE).
