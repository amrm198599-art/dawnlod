# بناء تطبيق Waleed Video Downloader لأندرويد (APK و AAB موقّع)

## الفكرة
التطبيق واجهة فقط. التحميل الحقيقي بيحصل على **سيرفرك** (Node + yt-dlp + FFmpeg)، وبعدها بتدوس **Save** في التطبيق والملف ينزل على موبايلك. يعني لازم تنشر السيرفر الأول على HTTPS.

## الخطوة 1: نشر السيرفر
```bash
docker build -t waleed-vd .
docker run -d -p 5000:5000 -e API_KEY=$(openssl rand -hex 32) -v wvd-data:/app/downloads waleed-vd
```
- احفظ قيمة `API_KEY` (هتدخلها في التطبيق).
- حط قدامه Caddy أو Nginx بشهادة HTTPS، وفعّل `TRUST_PROXY=true`.
- السيرفر **مش هيشتغل في production من غير API_KEY**.

## الخطوة 2: إنشاء مفتاح التوقيع (مرة واحدة)
محتاج JDK 17+ على جهازك:
```bash
./scripts/generate-keystore.sh waleed
```
السكريبت هيطبع 4 قيم. في GitHub: **Settings → Secrets and variables → Actions → Secrets → New repository secret** وضيف:

| Secret | القيمة |
|---|---|
| `ANDROID_KEYSTORE_BASE64` | النص الطويل اللي طلع |
| `ANDROID_KEYSTORE_PASSWORD` | كلمة السر |
| `ANDROID_KEY_ALIAS` | `waleed` |
| `ANDROID_KEY_PASSWORD` | كلمة السر |

⚠️ **احتفظ بنسخة من ملف `.keystore` وكلمة السر في مكان آمن.** لو ضاعوا مش هتقدر تنزّل تحديثات لنفس التطبيق أبدًا. وماترفعوش على GitHub.

## الخطوة 3: عنوان السيرفر
**Settings → Secrets and variables → Actions → Variables → New repository variable**
- الاسم: `API_BASE_URL`
- القيمة: `https://your-server.example` (لازم HTTPS)

## الخطوة 4: البناء
**Actions → Build Waleed Video Downloader Android → Run workflow.** بعد ما يخلص نزّل الـ Artifact `Waleed-Video-Downloader-Android`:
- `app-release.apk` موقّع وجاهز للتثبيت
- `app-release.aab` موقّع لـ Google Play
- (لو مفيش secrets للتوقيع هيطلع `app-debug.apk` للتجربة بس، مع تحذير في الـ log)

الـ workflow بيتحقق من التوقيع بـ `apksigner` تلقائيًا، و`versionCode` بيزيد مع كل تشغيل.

## الخطوة 5: أول تشغيل
افتح التطبيق ← أيقونة ⚙ ← اكتب عنوان السيرفر و API key ← Save.

## ملاحظات
- تطبيقات تحميل يوتيوب مش بتتقبل في Google Play، وزّع الـ APK مباشرة.
- حدّث yt-dlp بانتظام (أعد بناء صورة Docker) لأن المواقع بتغيّر كتير.
- حمّل بس محتوى تملكه أو مسموح لك بتحميله.
