#!/usr/bin/env node
// Run after `npx cap add android`. Turns the generated Capacitor project into an app that downloads
// ON THE PHONE (yt-dlp + ffmpeg): adds Kotlin, the native plugin, minSdk 24, signing and versioning.
// Safe to run more than once.
const fs = require('fs');
const path = require('path');

const androidDir = path.resolve(process.env.ANDROID_DIR || 'android');
const appDir = path.join(androidDir, 'app');
const appGradle = path.join(appDir, 'build.gradle');
const rootGradle = path.join(androidDir, 'build.gradle');
const varsGradle = path.join(androidDir, 'variables.gradle');
const gradleProps = path.join(androidDir, 'gradle.properties');
const nativeDir = path.join(__dirname, 'android', 'native');
const KOTLIN = '2.0.21';

const die = (m) => { console.error(m); process.exit(1); };
if (!fs.existsSync(appGradle)) die(`Not found: ${appGradle}. Run "npx cap add android" first.`);

// 1) minSdk 24 (required by the yt-dlp library)
if (fs.existsSync(varsGradle)) {
  let v = fs.readFileSync(varsGradle, 'utf8');
  v = v.replace(/minSdkVersion\s*=\s*\d+/, 'minSdkVersion = 24');
  fs.writeFileSync(varsGradle, v);
} else die(`Not found: ${varsGradle}`);

// 2) Kotlin Gradle plugin on the root classpath
let root = fs.readFileSync(rootGradle, 'utf8');
if (!root.includes('kotlin-gradle-plugin')) {
  const re = /(classpath\s+['"]com\.android\.tools\.build:gradle:[^'"]+['"])/;
  if (!re.test(root)) die('Could not find the Android Gradle plugin line in android/build.gradle');
  root = root.replace(re, `$1\n        classpath 'org.jetbrains.kotlin:kotlin-gradle-plugin:${KOTLIN}'`);
  fs.writeFileSync(rootGradle, root);
}

// 3) Apply kotlin-android in the app module + signing/deps script
let gradle = fs.readFileSync(appGradle, 'utf8');
if (!gradle.includes("kotlin-android")) {
  const re = /apply plugin:\s*['"]com\.android\.application['"]/;
  if (!re.test(gradle)) die("Could not find apply plugin: 'com.android.application' in app/build.gradle");
  gradle = gradle.replace(re, (m) => `${m}\napply plugin: 'kotlin-android'`);
}
fs.copyFileSync(path.join(__dirname, 'android', 'signing.gradle'), path.join(appDir, 'signing.gradle'));
if (!gradle.includes("apply from: 'signing.gradle'")) gradle = `${gradle.trimEnd()}\n\napply from: 'signing.gradle'\n`;
fs.writeFileSync(appGradle, gradle);

// 4) Native plugin + MainActivity
const pkgDir = path.join(appDir, 'src', 'main', 'java', 'com', 'waleed', 'videodownloader');
fs.mkdirSync(pkgDir, { recursive: true });
fs.copyFileSync(path.join(nativeDir, 'YtDlpPlugin.kt'), path.join(pkgDir, 'YtDlpPlugin.kt'));
fs.copyFileSync(path.join(nativeDir, 'MainActivity.java'), path.join(pkgDir, 'MainActivity.java'));

// 5) gradle.properties
let props = fs.existsSync(gradleProps) ? fs.readFileSync(gradleProps, 'utf8') : '';
const wanted = { 'org.gradle.jvmargs': '-Xmx3072m -Dfile.encoding=UTF-8', 'org.gradle.caching': 'true', 'org.gradle.parallel': 'true' };
for (const [k, val] of Object.entries(wanted)) {
  props = props.split('\n').filter((l) => !l.startsWith(`${k}=`)).join('\n');
  props = `${props.trimEnd()}\n${k}=${val}\n`;
}
fs.writeFileSync(gradleProps, props);

console.log('Android project configured (on-device yt-dlp, minSdk 24, Kotlin ' + KOTLIN + ').');
console.log(process.env.KEYSTORE_PATH ? `Release signing enabled.` : 'No KEYSTORE_PATH: release output will be unsigned.');
