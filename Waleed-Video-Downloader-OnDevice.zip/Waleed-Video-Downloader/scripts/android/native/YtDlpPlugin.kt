package com.waleed.videodownloader

import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import java.io.File
import java.lang.reflect.Modifier
import java.util.concurrent.Executors

/**
 * Runs yt-dlp + ffmpeg directly on the phone (same engine Seal uses), so no server is needed.
 * JS side: registerPlugin('YtDlp'). Events: progress, complete, error.
 */
@CapacitorPlugin(name = "YtDlp")
class YtDlpPlugin : Plugin() {

    private val pool = Executors.newFixedThreadPool(3)
    private val initLock = Any()

    @Volatile
    private var ready = false

    private val qualities = setOf("best", "worst", "2160", "1440", "1080", "720", "480", "360", "240", "144")
    private val audioFormats = setOf("best", "mp3", "m4a", "wav", "flac", "ogg", "opus")

    private fun ensureInit() {
        synchronized(initLock) {
            if (ready) return
            val app = context.applicationContext
            YoutubeDL.getInstance().init(app)
            FFmpeg.getInstance().init(app)
            ready = true
        }
    }

    private fun isHttp(url: String) = url.startsWith("http://") || url.startsWith("https://")

    @PluginMethod
    fun getInfo(call: PluginCall) {
        val url = (call.getString("url") ?: "").trim()
        if (!isHttp(url)) {
            call.reject("invalid_url")
            return
        }
        pool.execute {
            try {
                ensureInit()
                val info = YoutubeDL.getInstance().getInfo(url)
                val out = JSObject()
                out.put("title", info.title ?: "")
                out.put("uploader", info.uploader ?: "")
                out.put("thumbnail", info.thumbnail ?: "")
                out.put("duration", info.duration)
                call.resolve(out)
            } catch (e: Exception) {
                call.reject((e.message ?: "info_failed").takeLast(600), e)
            }
        }
    }

    @PluginMethod
    fun download(call: PluginCall) {
        val id = call.getString("downloadId") ?: ""
        val url = (call.getString("url") ?: "").trim()
        val audioOnly = call.getBoolean("audioOnly", false) ?: false
        val format = (call.getString("format") ?: "mp3").lowercase()
        val quality = (call.getString("quality") ?: "best").lowercase()

        if (id.isBlank() || !isHttp(url)) {
            call.reject("invalid_url")
            return
        }
        if (audioOnly && format !in audioFormats) {
            call.reject("unsupported_format")
            return
        }
        if (!audioOnly && quality !in qualities) {
            call.reject("unsupported_quality")
            return
        }
        call.resolve()
        pool.execute { runDownload(id, url, audioOnly, format, quality) }
    }

    private fun emit(event: String, vararg pairs: Pair<String, Any>) {
        val o = JSObject()
        for ((k, v) in pairs) o.put(k, v)
        notifyListeners(event, o)
    }

    private fun runDownload(id: String, url: String, audioOnly: Boolean, format: String, quality: String) {
        val base = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: context.filesDir
        val tmp = File(base, "tmp-$id")
        try {
            ensureInit()
            tmp.mkdirs()
            val req = YoutubeDLRequest(url)
            req.addOption("--no-playlist")
            req.addOption("--no-mtime")
            req.addOption("-o", tmp.absolutePath + "/%(title).120B [%(id)s].%(ext)s")
            if (audioOnly) {
                req.addOption("-f", "bestaudio/best")
                req.addOption("-x")
                req.addOption("--audio-format", format)
            } else {
                val f = when (quality) {
                    "worst" -> "worstvideo+worstaudio/worst"
                    "best" -> "bestvideo+bestaudio/best"
                    else -> "bestvideo[height<=$quality]+bestaudio/best[height<=$quality]/best[height<=$quality]"
                }
                req.addOption("-f", f)
                req.addOption("--merge-output-format", "mp4")
            }

            YoutubeDL.getInstance().execute(req, id) { progress, _, _ ->
                if (progress >= 0f) emit("progress", "id" to id, "progress" to progress.toDouble())
            }

            val produced = tmp.listFiles()
                ?.filter { it.isFile && !isTemp(it.name) }
                ?.maxByOrNull { it.lastModified() }
                ?: throw IllegalStateException("no_output_file")
            val name = produced.name
            val size = produced.length()
            val mime = mimeOf(name)
            val uri = publish(produced, mime)
            emit("complete", "id" to id, "filename" to name, "uri" to uri, "mime" to mime, "size" to size)
        } catch (e: Exception) {
            emit("error", "id" to id, "error" to (e.message ?: "download_failed").takeLast(600))
        } finally {
            tmp.deleteRecursively()
        }
    }

    private fun isTemp(name: String): Boolean {
        val n = name.lowercase()
        return n.endsWith(".part") || n.endsWith(".ytdl") || n.endsWith(".temp") ||
            Regex("\\.f\\d+\\.[a-z0-9]+$").containsMatchIn(n)
    }

    private fun mimeOf(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: when (ext) {
            "mkv" -> "video/x-matroska"
            "opus" -> "audio/ogg"
            else -> "application/octet-stream"
        }
    }

    // Copies the finished file into the public Downloads/WaleedDownloader folder (Android 10+).
    private fun publish(file: File, mime: String): String {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return Uri.fromFile(file).toString()
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, file.name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/WaleedDownloader")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("cannot_create_file")
        resolver.openOutputStream(uri)!!.use { out ->
            file.inputStream().use { it.copyTo(out) }
        }
        values.clear()
        values.put(MediaStore.MediaColumns.IS_PENDING, 0)
        resolver.update(uri, values, null, null)
        file.delete()
        return uri.toString()
    }

    @PluginMethod
    fun openFile(call: PluginCall) {
        val uri = call.getString("uri") ?: ""
        val mime = call.getString("mime") ?: "*/*"
        try {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(Uri.parse(uri), mime)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            call.resolve()
        } catch (e: Exception) {
            call.reject("cannot_open")
        }
    }

    @PluginMethod
    fun deleteFile(call: PluginCall) {
        val uri = call.getString("uri") ?: ""
        try {
            val u = Uri.parse(uri)
            if (u.scheme == "content") context.contentResolver.delete(u, null, null)
            else if (u.scheme == "file") File(u.path ?: "").delete()
        } catch (_: Exception) {
            // already gone
        }
        call.resolve()
    }

    // Updates the bundled yt-dlp (sites change often). Uses reflection so a different library
    // version's method signature does not break the build.
    @PluginMethod
    fun updateEngine(call: PluginCall) {
        pool.execute {
            try {
                ensureInit()
                val yd = YoutubeDL.getInstance()
                val m = yd.javaClass.methods.filter { it.name == "updateYoutubeDL" }.minByOrNull { it.parameterTypes.size }
                    ?: throw IllegalStateException("update_not_supported")
                val args = arrayOfNulls<Any>(m.parameterTypes.size)
                args[0] = context.applicationContext
                if (args.size > 1) args[1] = findStable(m.parameterTypes[1]) ?: throw IllegalStateException("update_not_supported")
                val res = m.invoke(yd, *args)
                val out = JSObject()
                out.put("status", res?.toString() ?: "OK")
                call.resolve(out)
            } catch (e: Exception) {
                call.reject((e.cause?.message ?: e.message ?: "update_failed").takeLast(300), e)
            }
        }
    }

    private fun findStable(t: Class<*>): Any? {
        t.enumConstants?.firstOrNull { it.toString().contains("STABLE", true) }?.let { return it }
        for (f in t.fields) {
            if (Modifier.isStatic(f.modifiers) && f.name.contains("STABLE", true)) return f.get(null)
        }
        try {
            val comp = t.getField("Companion").get(null)
            for (g in comp.javaClass.methods) {
                if (g.parameterTypes.isEmpty() && g.name.contains("STABLE", true)) return g.invoke(comp)
            }
        } catch (_: Exception) {
        }
        return null
    }
}
