# بناء تطبيق Waleed Video Downloader لأندرويد (مجاني، من غير سيرفر)

التطبيق بيحمّل **على الموبايل نفسه** (محرّك yt-dlp + FFmpeg جوّه الـ APK) زي Seal وسناب تيوب. مفيش استضافة ولا اشتراكات.

## 1) رفع المشروع
فك الـ zip وارفع **محتويات** الفولدر (مش الفولدر نفسه) في جذر الريبو على GitHub. لازم تلاقي `package.json` و`.github` و`client` و`scripts` في الجذر. امسح أي workflow قديم من `.github/workflows/`.

## 2) تشغيل البناء
**Actions ← Build Waleed Video Downloader Android ← Run workflow.** أول مرة بتاخد 10–20 دقيقة.
بعدها نزّل الـ Artifact `Waleed-Video-Downloader-Android`:
- من غير مفتاح توقيع: `app-debug.apk` (للتجربة والتثبيت).
- مع مفتاح التوقيع: `app-release.apk` و`app-release.aab` موقّعين.

## 3) التوقيع (اختياري، مرة واحدة)
على جهاز فيه JDK 17+:
```bash
./scripts/generate-keystore.sh waleed
```
ضيف القيم الأربعة اللي هتطلع في **Settings → Secrets and variables → Actions → Secrets**:
`ANDROID_KEYSTORE_BASE64` و`ANDROID_KEYSTORE_PASSWORD` و`ANDROID_KEY_ALIAS` و`ANDROID_KEY_PASSWORD`.
⚠️ احتفظ بنسخة من ملف الـ keystore وكلمة السر. لو ضاعوا مش هتقدر تحدّث نفس التطبيق.

## 4) الاستخدام
- الصق الرابط ← **تحميل**. الملف بيتحفظ في `التنزيلات/WaleedDownloader`.
- زر 🌐 فوق بيبدّل بين العربي والإنجليزي.
- لو التحميل وقف من موقع معين: ⚙ ← **تحديث محرّك التحميل** (محتاج إنترنت).
- خلّي التطبيق مفتوح أثناء التحميل.

## 5) ملاحظات
- حجم الـ APK حوالي 80 ميجا (فيه Python وFFmpeg).
- الحفظ في مجلد التنزيلات محتاج أندرويد 10 أو أحدث. أقل نسخة مدعومة أندرويد 7.
- التطبيق فيه مكوّنات GPL-3.0، فلو وزّعت الـ APK لازم الكود المصدري يكون متاح (ريبو عام يكفي). التفاصيل في `NOTICE.md`.
- تطبيقات تحميل يوتيوب مش بتتقبل في Google Play، وزّع الـ APK مباشرة. حمّل بس محتوى مسموح لك بتحميله.
