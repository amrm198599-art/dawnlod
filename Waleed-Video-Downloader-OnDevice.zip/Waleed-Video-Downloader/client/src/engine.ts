import { Capacitor, registerPlugin } from '@capacitor/core';
import type { PluginListenerHandle } from '@capacitor/core';

// True inside the Android app: downloads run on the phone itself (yt-dlp + ffmpeg), no server needed.
export const isNative: boolean = Capacitor.isNativePlatform();

export interface NativeInfo {
  title: string;
  uploader: string;
  thumbnail: string;
  duration: number;
}

export interface YtDlpPlugin {
  getInfo(options: { url: string }): Promise<NativeInfo>;
  download(options: {
    downloadId: string;
    url: string;
    audioOnly: boolean;
    format?: string;
    quality?: string;
  }): Promise<void>;
  openFile(options: { uri: string; mime: string }): Promise<void>;
  deleteFile(options: { uri: string }): Promise<void>;
  updateEngine(): Promise<{ status: string }>;
  addListener(eventName: 'progress' | 'complete' | 'error', listener: (data: any) => void): Promise<PluginListenerHandle>;
}

export const YtDlp = registerPlugin<YtDlpPlugin>('YtDlp');

// ---- local history (native mode) ----
export interface HistoryItem {
  id: string;
  name: string;
  uri: string;
  mime: string;
  size: number;
  date: string;
}

const HISTORY_KEY = 'wvd_history';

export function loadHistory(): HistoryItem[] {
  try {
    const raw = window.localStorage.getItem(HISTORY_KEY);
    const list = raw ? JSON.parse(raw) : [];
    return Array.isArray(list) ? list : [];
  } catch {
    return [];
  }
}

function saveHistory(list: HistoryItem[]) {
  try {
    window.localStorage.setItem(HISTORY_KEY, JSON.stringify(list.slice(0, 200)));
  } catch {
    /* ignore */
  }
}

export function addHistory(item: HistoryItem) {
  saveHistory([item, ...loadHistory().filter((h) => h.id !== item.id)]);
}

export function removeHistory(id: string) {
  saveHistory(loadHistory().filter((h) => h.id !== id));
}

export const QUALITY_VALUES = ['best', '2160', '1440', '1080', '720', '480', '360', 'worst'];
export const AUDIO_VALUES = ['mp3', 'm4a', 'wav', 'flac', 'ogg', 'best'];
